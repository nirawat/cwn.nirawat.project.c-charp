﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API_ShortUrlConverter.Models;
using API_ShortUrlConverter.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_ShortUrlConverter.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService userServices;
        public UsersController(IUserService userServices)
        {
            this.userServices = userServices;
        }

        [HttpPost("Hash")]
        public IActionResult HashPassword(AuthenticateModel authenticateModel) => this.userServices.HashPassword(authenticateModel);

        [HttpPost("GetToken")]
        public async Task<IActionResult> GetToken(AuthenticateModel authenticateModel) => await this.userServices.Authenticate(authenticateModel);
    }
}