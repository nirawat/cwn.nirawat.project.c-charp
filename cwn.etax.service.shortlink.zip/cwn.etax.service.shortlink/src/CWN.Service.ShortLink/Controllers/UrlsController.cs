﻿using API_ShortUrlConverter.Models;
using API_ShortUrlConverter.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class UrlsController : ControllerBase
    {
        private readonly IUrlServices urlServices;

        public UrlsController(IUrlServices urlServices)
        {
            this.urlServices = urlServices;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Connected.");
        }

        [Authorize]
        [HttpPost("ConvertShortURL")]
        public async Task<IActionResult> ConvertShortURL(RequestModel url)
        {
            var header = Request.Headers["Authorization"];
            return await this.urlServices.ConvertUrlToShortUrl(url, header);
        }
    }
}