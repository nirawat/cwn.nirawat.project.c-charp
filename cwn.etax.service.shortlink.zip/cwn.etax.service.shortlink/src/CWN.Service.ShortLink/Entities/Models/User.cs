﻿using System;
using System.Collections.Generic;

namespace API_ShortUrlConverter.Entities.Models
{
    public partial class User
    {
        public User()
        {
            UrlTransaction = new HashSet<UrlTransaction>();
            UserTokenLog = new HashSet<UserTokenLog>();
        }

        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public virtual ICollection<UrlTransaction> UrlTransaction { get; set; }
        public virtual ICollection<UserTokenLog> UserTokenLog { get; set; }
    }
}
