﻿using System;
using System.Collections.Generic;

namespace API_ShortUrlConverter.Entities.Models
{
    public partial class UrlTransaction
    {
        public long TransactionId { get; set; }
        public int UserId { get; set; }
        public string Url { get; set; }
        public string ShortUrl { get; set; }
        public DateTime TransactionDate { get; set; }

        public virtual User User { get; set; }
    }
}
