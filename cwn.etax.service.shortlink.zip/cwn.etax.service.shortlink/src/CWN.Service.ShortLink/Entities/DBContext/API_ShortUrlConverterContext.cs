﻿using System;
using System.IO;
using API_ShortUrlConverter.Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

namespace API_ShortUrlConverter.Entities.DBContext
{
    public partial class API_ShortUrlConverterContext : DbContext
    {
        public API_ShortUrlConverterContext()
        {
        }

        public API_ShortUrlConverterContext(DbContextOptions<API_ShortUrlConverterContext> options)
            : base(options)
        {
        }

        public virtual DbSet<UrlTransaction> UrlTransaction { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserTokenLog> UserTokenLog { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                                                                                                             .AddJsonFile("appsettings.json")
                                                                                                             .Build();
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("APIDatabase"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UrlTransaction>(entity =>
            {
                entity.HasKey(e => e.TransactionId);

                entity.Property(e => e.ShortUrl).IsRequired();

                entity.Property(e => e.TransactionDate).HasColumnType("datetime");

                entity.Property(e => e.Url).IsRequired();

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UrlTransaction)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UrlTransaction_User");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId).ValueGeneratedNever();

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<UserTokenLog>(entity =>
            {
                entity.HasKey(e => e.UserLogId);

                entity.Property(e => e.ExpiredDate).HasColumnType("datetime");

                entity.Property(e => e.GeneratedDate).HasColumnType("datetime");

                entity.Property(e => e.Token).IsRequired();

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserTokenLog)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserTokenLog_User");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
