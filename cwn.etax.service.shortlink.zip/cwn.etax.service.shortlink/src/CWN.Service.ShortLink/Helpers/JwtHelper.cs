﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace API_ShortUrlConverter.Helpers
{
    public class JwtHelper
    {
        public static string CreateToken(string jwtKey, string issuer, string audience, int expiredInMins, int userId)
        {
            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Sub, "Subject"),
                new Claim("uid", userId.ToString()),
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expires = DateTime.Now.AddMinutes(Convert.ToDouble(expiredInMins));

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: expires,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public static string GetClaimValue(string Token, string Key)
        {
            var handler = new JwtSecurityTokenHandler();
            var tokens = handler.ReadToken(Token) as JwtSecurityToken;
            return tokens.Claims.First(claim => claim.Type == Key).Value;
        }
    }
}
