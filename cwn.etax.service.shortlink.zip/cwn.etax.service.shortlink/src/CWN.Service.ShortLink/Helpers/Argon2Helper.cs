﻿using Konscious.Security.Cryptography;
using System;
using System.Text;

namespace API_ShortUrlConverter.Helpers
{
    public class Argon2Helper
    {
        public static string HashPassword(string salt, string value)
        {
            var argon2 = new Argon2i(Encoding.UTF8.GetBytes(value));

            argon2.Salt = Encoding.UTF8.GetBytes(salt);
            argon2.DegreeOfParallelism = 1;
            argon2.Iterations = 2;
            argon2.MemorySize = 16; //kbytes

            var hash = argon2.GetBytes(16);
            return Convert.ToBase64String(hash);
        }
    }
}
