﻿using API_ShortUrlConverter.Entities.DBContext;
using API_ShortUrlConverter.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Repositories
{
    public interface IUserTokenLogRepository
    {
        Task<bool> CreateAsync(UserTokenLog userTokenLog);
    }

    public class UserTokenLogRepository : IUserTokenLogRepository
    {
        public async Task<bool> CreateAsync(UserTokenLog userTokenLog)
        {
            using (var Context = new API_ShortUrlConverterContext())
            {
                Context.UserTokenLog.Add(userTokenLog);
                return await Context.SaveChangesAsync() > 0;
            }
        }
    }
}
