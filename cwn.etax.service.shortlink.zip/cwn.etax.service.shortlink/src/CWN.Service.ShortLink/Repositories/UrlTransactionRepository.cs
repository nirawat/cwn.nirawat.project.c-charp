﻿using API_ShortUrlConverter.Entities.Models;
using API_ShortUrlConverter.Entities.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Repositories
{
    public interface IUrlTransactionRepository
    {
        Task<bool> CreateAsync(UrlTransaction urlTransaction);
    }

    public class UrlTransactionRepository: IUrlTransactionRepository
    {
        public async Task<bool> CreateAsync(UrlTransaction urlTransaction)
        {
            using (var Context = new API_ShortUrlConverterContext())
            {
                Context.UrlTransaction.Add(urlTransaction);
                return await Context.SaveChangesAsync() > 0;
            }
        }
    }
}
