﻿using API_ShortUrlConverter.Entities.DBContext;
using API_ShortUrlConverter.Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Repositories
{
    public interface IUserRepository
    {
        Task<User> GetUserByUsernameAsync(string username);
    }

    public class UserRepository: IUserRepository
    {
        public async Task<User> GetUserByUsernameAsync(string username)
        {
            using(var context = new API_ShortUrlConverterContext())
            {
                return await context.User.SingleOrDefaultAsync(x => x.Username == username);
            }
        }
    }
}
