﻿using API_ShortUrlConverter.Entities.Models;
using API_ShortUrlConverter.Models;
using API_ShortUrlConverter.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Services
{
    public interface IUrlServices
    {
        Task<IActionResult> ConvertUrlToShortUrl(RequestModel request, string header);
    }

    public class UrlServices: IUrlServices
    {
        private readonly IConfiguration configuration;
        private readonly IUrlTransactionRepository urlTransaction;

        private UnauthorizedResult unauthorizedResult;
        private StatusCodeResult internalServerErrorStatusCodeResult = new StatusCodeResult(500);

        public UrlServices(
            IConfiguration configuration,
            IUrlTransactionRepository urlTransaction)
        {
            this.configuration = configuration;
            this.urlTransaction = urlTransaction;

            this.unauthorizedResult = new UnauthorizedResult();
            this.internalServerErrorStatusCodeResult = new StatusCodeResult(500);
        }
       

        public async Task<IActionResult> ConvertUrlToShortUrl(RequestModel request, string header)
        {
            var response = new ResponseModel();
            try
            {
                var jwtToken = header.Split(' ')[1];
                var userId = Convert.ToInt32(Helpers.JwtHelper.GetClaimValue(jwtToken, "uid"));

                var apiKey = this.configuration["t2mio:apikey"];
                var apiSecret = this.configuration["t2mio:apisecret"];

                var t2MIORequestModel = new T2MIORequestModel()
                {
                    destination = request.Url
                };

                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("apikey", apiKey);
                    client.DefaultRequestHeaders.Add("apisecret", apiSecret);

                    var jsonObject = JsonConvert.SerializeObject(t2MIORequestModel);
                    var content = new StringContent(jsonObject.ToString(), Encoding.UTF8, "application/json");

                    var result = await client.PostAsync(this.configuration["t2mio:Url"], content);

                    string resultContent = await result.Content.ReadAsStringAsync();
                    var jsonResponse = JsonConvert.DeserializeObject<T2MIOResponseModel>(resultContent);

                    if (result.StatusCode == HttpStatusCode.OK)
                    {
                        var shortUrl = jsonResponse.data.shortUrl;
                        var createdAt = jsonResponse.data.createdAt;
                        var destination = jsonResponse.data.destination;

                        var urlTransaction = new UrlTransaction()
                        {
                            UserId = userId,
                            TransactionDate = createdAt,
                            ShortUrl = shortUrl,
                            Url = destination,
                        };
                        bool isLogCreated = await this.urlTransaction.CreateAsync(urlTransaction);
                        if (!isLogCreated) return internalServerErrorStatusCodeResult;

                        response.Status = true;
                        response.ShortURL = shortUrl;
                    }
                    else
                    {
                        response.Status = false;
                        response.Description = $"The remote server returned an error: {jsonResponse.message}";
                    }
                    return new OkObjectResult(response);
                }

            }
            catch (Exception)
            {
                return this.internalServerErrorStatusCodeResult;
            }
        }

    }
}
