﻿using API_ShortUrlConverter.Entities.Models;
using API_ShortUrlConverter.Models;
using API_ShortUrlConverter.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Services
{
    public interface IUserService
    {
        Task<IActionResult> Authenticate(AuthenticateModel user);
        IActionResult HashPassword(AuthenticateModel user);
    }

    public class UserService : IUserService
    {
        private readonly IConfiguration configuration;
        private readonly IUserRepository userRepository;
        private readonly IUserTokenLogRepository userTokenLogRepository;

        private UnauthorizedResult unauthorizedResult;
        private StatusCodeResult internalServerErrorStatusCodeResult = new StatusCodeResult(500);

        public UserService(
            IUserRepository userRepository,
            IConfiguration configuration,
            IUserTokenLogRepository userTokenLogRepository)
        {
            this.userRepository = userRepository;
            this.configuration = configuration;
            this.userTokenLogRepository = userTokenLogRepository;

            this.unauthorizedResult = new UnauthorizedResult();
        }

        public async Task<IActionResult> Authenticate(AuthenticateModel user)
        {
            try
            {
                var dbUser = await this.userRepository.GetUserByUsernameAsync(user.Username);
                var hashedPassword = Helpers.Argon2Helper.HashPassword(user.Username, user.Password);

                // return unauthorized if user not found
                if (user == null)
                {
                    return this.unauthorizedResult;
                }
                else if (dbUser.Password != hashedPassword)
                {
                    return this.unauthorizedResult;
                }
                else
                {
                    // authentication successful so generate jwt token
                    var key = this.configuration["AppSettings:Jwt:Key"];
                    var issuer = this.configuration["AppSettings:Jwt:Issuer"];
                    var audience = this.configuration["AppSettings:Jwt:Audience"];
                    var expiredInMins = Convert.ToInt32(this.configuration["AppSettings:Jwt:ExpireInMins"]);
                    var userToken = Helpers.JwtHelper.CreateToken(key, issuer, audience, expiredInMins, dbUser.UserId);
                    var now = DateTime.Now;
                    var userTokenLog = new UserTokenLog()
                    {
                        UserId = dbUser.UserId,
                        Token = userToken,
                        GeneratedDate = now,
                        ExpiredDate = now.AddMinutes(expiredInMins)
                    };

                    try
                    {
                        await this.userTokenLogRepository.CreateAsync(userTokenLog);
                    }
                    catch (Exception)
                    {
                        return this.internalServerErrorStatusCodeResult;
                    }

                    return new OkObjectResult(new { Token = userToken });
                }


            }
            catch (Exception)
            {
                return this.internalServerErrorStatusCodeResult;
            }
        }

        public IActionResult HashPassword(AuthenticateModel user)
        {
            try
            {
                return new OkObjectResult((new { Value = Helpers.Argon2Helper.HashPassword(user.Username, user.Password) }));
            }
            catch (Exception)
            {
                return this.internalServerErrorStatusCodeResult;
            }
        }
    }
}
