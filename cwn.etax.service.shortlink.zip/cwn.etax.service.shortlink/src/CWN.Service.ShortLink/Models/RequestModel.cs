﻿using System.ComponentModel.DataAnnotations;

namespace API_ShortUrlConverter.Models
{
    public class RequestModel
    {
        public string Url { get; set; }
    }

    public class AuthenticateModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
