﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Models
{
    public class ResponseModel
    {
        public bool Status { get; set; }
        public string ShortURL { get; set; }
        public string Description { get; set; }
    }

    public class AuthenticateResponseModel
    {
        public string Token { get; set; }
    }
}
