﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_ShortUrlConverter.Models
{
    #region RequestModel

    public class T2MIORequestModel
    {
        public string destination { get; set; }
    }

    #endregion

    #region ResponseModel
    public class T2MIOResponseModel
    {
        public int status { get; set; }
        public string message { get; set; }
        public T2MIOSubResponseModel data { get; set; }
    }

    public class T2MIOSubResponseModel
    {
        public int id { get; set; }
        public string destination { get; set; }
        public int hits { get; set; }
        public string redirectCode { get; set; }
        public string shortUrl { get; set; }
        public string slashtag { get; set; }
        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }
    }
    #endregion
}
