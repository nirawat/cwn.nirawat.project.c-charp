﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CWN.Service.Sms.Models.Response
{
    public class TrackingStatusResponse
    {
        public bool Status { get; set; }
        public string Description { get; set; }
    }

}
