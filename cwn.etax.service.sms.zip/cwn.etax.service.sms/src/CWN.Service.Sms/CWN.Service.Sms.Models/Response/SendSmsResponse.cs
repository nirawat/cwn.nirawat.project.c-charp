﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CWN.Service.Sms.Models.Response
{
    public class SendSmsResponse
    {
        public bool status { get; set; }
        public string trackingID { get; set; }
        public string description { get; set; }
    }
    public class SmsMailBit_MessageResponse
    {
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string JobId { get; set; }
        public List<SmsMailBit_MessageDataResponse> MessageData { get; set; }
    }
    public class SmsMailBit_MessageDataResponse
    {
        public string Number { get; set; }
        public List<SmsMailBit_MessagePartsResponse> MessageParts { get; set; }
    }
    public class SmsMailBit_MessagePartsResponse
    {
        public string MsgId { get; set; }
        public string PartId { get; set; }
        public string Text { get; set; }
    }
}
