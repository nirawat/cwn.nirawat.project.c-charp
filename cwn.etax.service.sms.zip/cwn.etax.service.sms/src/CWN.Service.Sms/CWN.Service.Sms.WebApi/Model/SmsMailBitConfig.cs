﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CWN.Service.Sms.WebApi.Model
{
    public interface ISmsMailBitConfig
    {
        string SmsUser { get; set; }
        string SmsPassw { get; set; }
        string SmsSendUrl { get; set; }
        string SmsTrackingUrl { get; set; }
        string fl { get; set; }
        string Unicode { get; set; }
    }

    public class SmsMailBitConfig : ISmsMailBitConfig
    {
        public string SmsUser { get; set; }
        public string SmsPassw { get; set; }
        public string SmsSendUrl { get; set; }
        public string SmsTrackingUrl { get; set; }
        public string fl { get; set; }
        public string Unicode { get; set; }
    }
}
