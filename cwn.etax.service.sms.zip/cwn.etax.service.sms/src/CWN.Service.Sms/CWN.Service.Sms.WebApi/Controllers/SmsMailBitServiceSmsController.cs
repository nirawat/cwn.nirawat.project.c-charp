﻿using CWN.Service.Sms.Business.Interfaces;
using CWN.Service.Sms.Entities.CWN_ServiceSms;
using CWN.Service.Sms.Helpers;
using CWN.Service.Sms.Models.Response;
using CWN.Service.Sms.WebApi.ApiConnector;
using CWN.Service.Sms.WebApi.Configs;
using CWN.Service.Sms.WebApi.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CWN.Service.Sms.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SmsMailBitServiceSmsController : ControllerBase
    {
        private IHttpContextAccessor _httpContextAccessor;
        private readonly IServiceSmsService _IServiceSmsService;
        private readonly IIntersectsTime _IIntersectsTime;
        private ISmsMailBitConfig _smsmailbitconfig;
        private IRobotConfig _robotconfig;

        private static string sms_usern;
        private static string sms_passw;
        private static string sms_url;
        private static string tracking_url;

        public SmsMailBitServiceSmsController(
            IHttpContextAccessor httpContextAccessor,
            IServiceSmsService IServiceSmsServices,
            IIntersectsTime IIntersectsTimes,
            ISmsMailBitConfig smsmailbitconfig,
            IRobotConfig robotconfig)
        {
            _httpContextAccessor = httpContextAccessor;
            _IServiceSmsService = IServiceSmsServices;
            _IIntersectsTime = IIntersectsTimes;
            _smsmailbitconfig = smsmailbitconfig;
            _robotconfig = robotconfig;

            sms_usern = Encoding.UTF8.GetString(Convert.FromBase64String(_smsmailbitconfig.SmsUser));
            sms_passw = Encoding.UTF8.GetString(Convert.FromBase64String(_smsmailbitconfig.SmsPassw));
            sms_url = Encoding.UTF8.GetString(Convert.FromBase64String(_smsmailbitconfig.SmsSendUrl));
            tracking_url = Encoding.UTF8.GetString(Convert.FromBase64String(_smsmailbitconfig.SmsTrackingUrl));
        }

        [HttpPost("Sends")]
        public async Task<IActionResult> Sends([FromBody]Sms_Send model)
        {


            if (!double.TryParse(model.ToNumber, out var x)) return BadRequest(new { error = "ToNumeric must be numeric." });
            if (model.ToNumber.ToString().Contains(".")) return BadRequest(new { error = "ToNumeric must be numeric only." });

            IActionResult _result = BadRequest();
            string token_key = string.Empty;
            _httpContextAccessor.HttpContext.Response.ContentType = new MediaTypeHeaderValue("application/json").ToString();
            string authHeader = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            if (authHeader != null && authHeader.StartsWith("Bearer")) token_key = authHeader.Substring("Bearer ".Length).Trim();

            string APIKEY = Encoding.UTF8.GetString(Convert.FromBase64String(token_key));
            string[] split_apikey = APIKEY.Split('|');
            model.SenderId = split_apikey[3].Replace("}", "");
            model.StartTime = TimeSpan.Parse(split_apikey[1]);
            model.EndTime = TimeSpan.Parse(split_apikey[2]);


            //สำหรับทดสอบเพื่อไม่ให้ SMS ซ้ำกัน --------------------
            //Guid guid = Guid.NewGuid();
            //model.Message = model.Message + " " + guid;

            //---------------------------------------------


            CancellationTokenSource source = new CancellationTokenSource();

            var tasks = Task.Run(async delegate
            {
                if (!await _IIntersectsTime.IsValidTimeAsync(model.StartTime.Value, model.EndTime.Value))
                {
                    SmsMailBit_MessageResponse result = JsonConvert.DeserializeObject<SmsMailBit_MessageResponse>("{}");
                    model.IsSend = false;
                    var resp = await _IServiceSmsService.Sms_Send(model, result);
                    if (!resp.status) _result = BadRequest();
                    else _result = Ok(resp);
                }
                else
                {
                    string toNumber = (model.ToNumber.ToString().Substring(0, 2) == "66") ? model.ToNumber.ToString() : "66" + model.ToNumber.ToString().Substring(1, 9);

                    string requestUri = $"{string.Format(sms_url, sms_usern, sms_passw, toNumber, model.SenderId, model.Message, _smsmailbitconfig.fl, _smsmailbitconfig.Unicode)}";

                    using (var httpResponse = await HttpRequestFactory.Get(requestUri, string.Empty))
                    {
                        switch (httpResponse.StatusCode)
                        {
                            case HttpStatusCode.OK:
                                {
                                    SmsMailBit_MessageResponse result = JsonConvert.DeserializeObject<SmsMailBit_MessageResponse>(httpResponse.ContentAsString());
                                    model.IsSend = true;
                                    model.SendDateTime = _IIntersectsTime.DateNowTimeZone();
                                    var resp = await _IServiceSmsService.Sms_Send(model, result);
                                    if (!resp.status) _result = BadRequest();
                                    else _result = Ok(resp);
                                    break;
                                }

                            case HttpStatusCode.Unauthorized:
                                _result = Unauthorized();
                                break;
                            case HttpStatusCode.BadRequest:
                                _result = BadRequest();
                                break;
                            case HttpStatusCode.Forbidden:
                                _result = StatusCode(403);
                                break;
                            default:
                                _result = StatusCode(500);
                                break;
                        }
                    }
                }
                await Task.Delay(TimeSpan.FromSeconds(_robotconfig.SendDelay), source.Token);
                return _result;
            });
            source.Cancel();
            try
            {
                tasks.Wait();
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.InnerExceptions)
                    Console.WriteLine("{0}: {1}", e.GetType().Name, e.Message);
            }
            if (tasks.Status == TaskStatus.RanToCompletion)
                source.Dispose();
            return _result;
        }

        [HttpGet("GetTrackingStatus")]
        public async Task<IActionResult> GetTrackingStatus([FromBody]Sms_Tracking model)
        {

            IActionResult _result = BadRequest();

            CancellationTokenSource source = new CancellationTokenSource();

            var tasks = Task.Run(async delegate
            {

                var requestUri = $"{string.Format(tracking_url, sms_usern, sms_passw, model.TrackingID)}";

                using (var httpResponse = await HttpRequestFactory.Get(requestUri, string.Empty))
                {

                    switch (httpResponse.StatusCode)
                    {
                        case HttpStatusCode.OK:
                            {
                                //Save Tracking
                                if (httpResponse.ContentAsString() == "#DELIVRD")
                                {
                                    bool tracking_result = await _IServiceSmsService.UpdateTrackingAsync(model.TrackingID, httpResponse.ContentAsString());

                                    _result = Ok(new { Status = httpResponse.ContentAsString() == "#DELIVRD" ? true : false, Description = httpResponse.ContentAsString() });
                                }
                                else _result = BadRequest();
                                break;
                            }

                        case HttpStatusCode.Unauthorized:
                            _result = Unauthorized();
                            break;
                        case HttpStatusCode.BadRequest:
                            _result = BadRequest();
                            break;
                        case HttpStatusCode.Forbidden:
                            _result = StatusCode(403);
                            break;
                        default:
                            _result = StatusCode(500);
                            break;
                    }
                }
                await Task.Delay(TimeSpan.FromSeconds(_robotconfig.SendDelay), source.Token);
                return _result;
            });
            source.Cancel();
            try
            {
                tasks.Wait();
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.InnerExceptions)
                    Console.WriteLine("{0}: {1}", e.GetType().Name, e.Message);
            }
            if (tasks.Status == TaskStatus.RanToCompletion)
                source.Dispose();
            return _result;
        }

    }
}