﻿using CWN.Service.Sms.Business.Interfaces;
using CWN.Service.Sms.Entities.CWN_ServiceSms;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CWN.Service.Sms.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        private readonly IMST_RegisterService _IMST_RegisterService;
        private IHttpContextAccessor _httpContextAccessor;

        public RegisterController(
            IMST_RegisterService IMST_RegisterService,
            IHttpContextAccessor httpContextAccessor)
        {
            _IMST_RegisterService = IMST_RegisterService;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpPost("RegisterUser")]
        public async Task<IActionResult> RegisterUser([FromBody]MST_Register model)
        {
            if (string.IsNullOrWhiteSpace(model.SenderId)) return BadRequest(new { message = "SenderId is required." });

            if (model.SenderId.Length < 3 || model.SenderId.Length > 11) return BadRequest(new { message = "SenderId must be 3-11 characters." });

            if (model.StartTime.Ticks <= 0) return BadRequest(new { message = "StartTime is required." });

            if (model.EndTime.Ticks <= 0) return BadRequest(new { message = "EndTime is required." });

            var time_total = (model.EndTime.Subtract(model.StartTime).TotalMinutes);

            if (time_total <= 0) return BadRequest(new { message = "Period time invalid." });

            var resp = await _IMST_RegisterService.RegisterUser(model);
            if (!string.IsNullOrEmpty(resp)) return Ok(new { token = resp });
            else return BadRequest();
        }

        [HttpPost("UpdateInformation")]
        public async Task<IActionResult> UpdateInformation([FromBody]MST_Register model)
        {
            if (string.IsNullOrWhiteSpace(model.SenderId)) return BadRequest(new { message = "SenderId is required." });

            if (model.SenderId.Length < 3 || model.SenderId.Length > 11) return BadRequest(new { message = "SenderId must be 3-11 characters." });

            if (model.StartTime.Ticks <= 0) return BadRequest(new { message = "StartTime is required." });

            if (model.EndTime.Ticks <= 0) return BadRequest(new { message = "EndTime is required." });

            var time_total = (model.EndTime.Subtract(model.StartTime).TotalMinutes);

            if (time_total <= 0) return BadRequest(new { message = "Period time invalid." });

            _httpContextAccessor.HttpContext.Response.ContentType = new MediaTypeHeaderValue("application/json").ToString();
            string authHeader = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            if (authHeader != null && authHeader.StartsWith("Bearer")) model.Token = authHeader.Substring("Bearer ".Length).Trim();

            var resp = await _IMST_RegisterService.UpdateInformation(model);
            if (!string.IsNullOrEmpty(resp)) return Ok(new { token = resp });
            else return BadRequest();
        }

        [HttpPost("GetToken")]
        public async Task<IActionResult> GetToken([FromBody]MST_Register model)
        {
            _httpContextAccessor.HttpContext.Response.ContentType = new MediaTypeHeaderValue("application/json").ToString();
            string authHeader = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            if (authHeader != null && authHeader.StartsWith("Bearer")) model.Token = authHeader.Substring("Bearer ".Length).Trim();

            var resp = await _IMST_RegisterService.GetToken(model);
            if (!string.IsNullOrEmpty(resp)) return Ok(new { Token = resp });
            else return BadRequest();
        }

    }
}