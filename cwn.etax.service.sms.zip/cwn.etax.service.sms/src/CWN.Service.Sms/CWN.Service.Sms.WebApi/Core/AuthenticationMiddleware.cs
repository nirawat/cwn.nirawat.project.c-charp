﻿using CWN.Service.Sms.Business.Interfaces;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CWN.Service.Sms.WebApi.Core
{
    public class AuthenticationMiddleware
    {
        private readonly RequestDelegate _next;

        public AuthenticationMiddleware(
            RequestDelegate next
            )
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context, IMST_RegisterService _IMST_RegisterService)
        {
            var jsonString = "{\"message\": \"Invalid TokenKey\"}";
            context.Response.ContentType = new MediaTypeHeaderValue("application/json").ToString();

            string authHeader = context.Request.Headers["Authorization"];

            if (authHeader != null && authHeader.StartsWith("Bearer"))
            {
                //Extract credentials                
                string SystemKey = authHeader.Substring("Bearer ".Length).Trim();

                bool IsTokenKey = await _IMST_RegisterService.ValidateTokenKey(SystemKey);
                if (IsTokenKey)
                {
                    await _next.Invoke(context);
                }
                else
                {
                    context.Response.StatusCode = 401; //Unauthorized
                    await context.Response.WriteAsync(jsonString, Encoding.UTF8);
                    return;
                }

            }
            else
            {
                // no authorization header
                context.Response.StatusCode = 401; //Unauthorized.
                await context.Response.WriteAsync(jsonString, Encoding.UTF8);
                return;
            }
        }

    }
}
