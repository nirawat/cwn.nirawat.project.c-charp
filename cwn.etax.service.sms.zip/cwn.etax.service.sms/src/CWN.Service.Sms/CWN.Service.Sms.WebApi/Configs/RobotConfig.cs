﻿namespace CWN.Service.Sms.WebApi.Configs
{
    public interface IRobotConfig
    {
        int RobotProcess { get; set; }
        int SendDelay { get; set; }
    }

    public class RobotConfig : IRobotConfig
    {
        public int RobotProcess { get; set; }
        public int SendDelay { get; set; }
    }
}
