﻿using CWN.Service.Sms.Business;
using CWN.Service.Sms.Business.Interfaces;
using CWN.Service.Sms.Helpers;
using CWN.Service.Sms.Repository;
using CWN.Service.Sms.Repository.DataContext;
using CWN.Service.Sms.Repository.Interfaces;
using CWN.Service.Sms.WebApi.Configs;
using CWN.Service.Sms.WebApi.Core;
using CWN.Service.Sms.WebApi.Model;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using System;
using System.Globalization;
using System.Text;

namespace CWN.Service.Sms.WebApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<SmsMailBitConfig>(Configuration.GetSection(nameof(SmsMailBitConfig)));
            services.AddSingleton<ISmsMailBitConfig>(sp => sp.GetRequiredService<IOptions<SmsMailBitConfig>>().Value);

            services.Configure<RobotConfig>(Configuration.GetSection(nameof(RobotConfig)));
            services.AddSingleton<IRobotConfig>(sp => sp.GetRequiredService<IOptions<RobotConfig>>().Value);

            services.AddDbContext<Service_Sms_Context>(options =>
            {
                options.UseSqlServer(Encoding.UTF8.GetString(Convert.FromBase64String(Configuration.GetConnectionString("dbServiceSms"))));
            });

            services.AddHttpClient();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            //Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "SMS Service", Version = "v1" });
                var securityScheme = new OpenApiSecurityScheme()
                {
                    Description = "Please enter into field the word 'Bearer' followed by a space and the JWT value",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "bearer"
                };
                c.AddSecurityDefinition("Bearer", securityScheme);
                c.AddSecurityRequirement(new OpenApiSecurityRequirement { { new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }, new string[] { } } });
            });

            var cultureInfo = new CultureInfo("en-GB");
            CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;

            //----------------------------------------------------------------------------------------------
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            //Add Helpers
            services.AddScoped(typeof(IAESHelper), typeof(AESHelper));
            services.AddScoped(typeof(IRSAHelper), typeof(RSAHelper));

            //Add Service
            services.AddScoped(typeof(IMST_RegisterService), typeof(MST_RegisterService));
            services.AddScoped(typeof(IServiceSmsService), typeof(ServiceSmsService));
            services.AddScoped(typeof(IIntersectsTime), typeof(IntersectsTime));

            //Add Repository
            services.AddScoped(typeof(IMST_RegisterRepository), typeof(MST_RegisterRepository));
            services.AddScoped(typeof(IServiceSmsRepository), typeof(ServiceSmsRepository));

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseSwagger();
            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "SMS Service V1");
            });

            app.UseMiddleware(typeof(AuthenticationMiddleware));
            app.UseMiddleware(typeof(ErrorHandlingMiddleware));
            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
