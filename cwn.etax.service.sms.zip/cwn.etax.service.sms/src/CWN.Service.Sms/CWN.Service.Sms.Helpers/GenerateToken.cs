﻿using System;

namespace CWN.Service.Sms.Helpers
{
    public class GenerateToken
    {
        public static string GetToken(TimeSpan starttime, TimeSpan endtime, string SenderId)
        {
            Guid guid = Guid.NewGuid();
            string token = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(
                "{" + guid.ToString() + "|" + starttime + "|" + endtime + "|" + SenderId + "}"
                ));
            return token;
        }

    }
}
