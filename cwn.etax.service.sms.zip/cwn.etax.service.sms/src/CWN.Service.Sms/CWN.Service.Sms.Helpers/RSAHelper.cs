﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace CWN.Service.Sms.Helpers
{
    public interface IRSAHelper
    {
        string Sign(string data);
        bool Verify(string data, string sign);
        string Encrypt(string text);
        string Decrypt(string cipherText);
    }
    public class RSAHelper : IRSAHelper
    {
        private readonly RSA _privateKeyRsaProvider;
        private readonly RSA _publicKeyRsaProvider;
        private readonly HashAlgorithmName _hashAlgorithmName;
        private readonly IConfiguration configuration;
        public RSAHelper(IConfiguration configuration)
        {
            this.configuration = configuration;
            if (!string.IsNullOrEmpty(this.configuration["PrivateKey"]))
            {
                _privateKeyRsaProvider = CreateRsaProviderFromPrivateKey(this.configuration["PrivateKey"]);
            }

            if (!string.IsNullOrEmpty(this.configuration["PublicKey"]))
            {
                _publicKeyRsaProvider = CreateRsaProviderFromPublicKey(this.configuration["PublicKey"]);
            }

            _hashAlgorithmName = HashAlgorithmName.SHA1;
        }

        public string Sign(string data)
        {
            byte[] dataBytes = Encoding.UTF8.GetBytes(data);

            var signatureBytes = _privateKeyRsaProvider.SignData(dataBytes, _hashAlgorithmName, RSASignaturePadding.Pkcs1);

            return Convert.ToBase64String(signatureBytes);
        }

        public bool Verify(string data, string sign)
        {
            byte[] dataBytes = Encoding.UTF8.GetBytes(data);
            byte[] signBytes = Convert.FromBase64String(sign);

            var verify = _publicKeyRsaProvider.VerifyData(dataBytes, signBytes, _hashAlgorithmName, RSASignaturePadding.Pkcs1);

            return verify;
        }

        public string Encrypt(string text)
        {
            if (_publicKeyRsaProvider == null)
            {
                throw new Exception("_publicKeyRsaProvider is null");
            }
            return Convert.ToBase64String(_publicKeyRsaProvider.Encrypt(Encoding.UTF8.GetBytes(text), RSAEncryptionPadding.Pkcs1));
        }

        public string Decrypt(string cipherText)
        {
            if (_privateKeyRsaProvider == null)
            {
                throw new Exception("_privateKeyRsaProvider is null");
            }
            return Encoding.UTF8.GetString(_privateKeyRsaProvider.Decrypt(Convert.FromBase64String(cipherText), RSAEncryptionPadding.Pkcs1));
        }

        public RSA CreateRsaProviderFromPrivateKey(string privateKey)
        {
            string xmlString = Encoding.UTF8.GetString(Convert.FromBase64String(privateKey));

            RSAParameters parameters = new RSAParameters();
            var rsa = RSA.Create();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlString);

            if (xmlDoc.DocumentElement.Name.Equals("RSAParameters"))
            {
                foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes)
                {
                    switch (node.Name)
                    {
                        case "Modulus": parameters.Modulus = Convert.FromBase64String(node.InnerText); break;
                        case "Exponent": parameters.Exponent = Convert.FromBase64String(node.InnerText); break;
                        case "P": parameters.P = Convert.FromBase64String(node.InnerText); break;
                        case "Q": parameters.Q = Convert.FromBase64String(node.InnerText); break;
                        case "DP": parameters.DP = Convert.FromBase64String(node.InnerText); break;
                        case "DQ": parameters.DQ = Convert.FromBase64String(node.InnerText); break;
                        case "InverseQ": parameters.InverseQ = Convert.FromBase64String(node.InnerText); break;
                        case "D": parameters.D = Convert.FromBase64String(node.InnerText); break;
                    }
                }
            }
            else
            {
                throw new Exception("Invalid XML RSA key.");
            }
            rsa.ImportParameters(parameters);
            return rsa;
        }

        public RSA CreateRsaProviderFromPublicKey(string publicKeyString)
        {
            string xmlString = Encoding.UTF8.GetString(Convert.FromBase64String(publicKeyString));

            RSAParameters parameters = new RSAParameters();
            var rsa = RSA.Create();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlString);

            if (xmlDoc.DocumentElement.Name.Equals("RSAParameters"))
            {
                foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes)
                {
                    switch (node.Name)
                    {
                        case "Modulus": parameters.Modulus = Convert.FromBase64String(node.InnerText); break;
                        case "Exponent": parameters.Exponent = Convert.FromBase64String(node.InnerText); break;
                    }
                }
            }
            else
            {
                throw new Exception("Invalid XML RSA key.");
            }
            rsa.ImportParameters(parameters);
            return rsa;
        }

    }
}
