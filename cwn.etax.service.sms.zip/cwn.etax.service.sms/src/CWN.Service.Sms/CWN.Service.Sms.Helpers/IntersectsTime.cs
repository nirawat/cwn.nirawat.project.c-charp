﻿using System;
using System.Threading.Tasks;

namespace CWN.Service.Sms.Helpers
{
    public interface IIntersectsTime
    {
        Task<bool> IsValidTimeAsync(TimeSpan starttime, TimeSpan endtime);
        DateTime DateNowTimeZone();
    }
    public class IntersectsTime : IIntersectsTime
    {
        public IntersectsTime()
        {

        }

        public async Task<bool> IsValidTimeAsync(TimeSpan starttime, TimeSpan endtime)
        {
            var time_total = (endtime.Subtract(starttime).TotalMinutes);

            if (time_total <= 0) return false;

            DateTime dtnow = DateNowTimeZone();

            return (dtnow.TimeOfDay >= starttime && dtnow.TimeOfDay <= endtime) ? true : false;

        }

        public DateTime DateNowTimeZone()
        {
            //return DateTime.Now;

            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Asia/Bangkok");
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZoneInfo);

        }




    }
}
