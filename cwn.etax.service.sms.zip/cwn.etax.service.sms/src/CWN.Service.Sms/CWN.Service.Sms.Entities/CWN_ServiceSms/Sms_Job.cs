﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CWN.Service.Sms.Entities.CWN_ServiceSms
{
    [Table("Sms_Job")]
    public class Sms_Job
    {
        [Key]
        public int JobId { get; set; }
        public string SenderId { get; set; }
        public string ReferenceKey1 { get; set; }
        public string ReferenceKey2 { get; set; }
        public string ReferenceKey3 { get; set; }
        public string FromName { get; set; }
        public string ToNumber { get; set; }
        public string Message { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }
        public DateTime CreateDate { get; set; }
    }

}
