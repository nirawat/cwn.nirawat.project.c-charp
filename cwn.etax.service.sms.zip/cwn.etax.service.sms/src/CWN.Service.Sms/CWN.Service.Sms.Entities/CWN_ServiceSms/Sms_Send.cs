﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CWN.Service.Sms.Entities.CWN_ServiceSms
{
    public class Sms_Send
    {
        public string SenderId { get; set; }
        [Required(ErrorMessage = "ReferenceKey is required.")]
        public string ReferenceKey { get; set; }
        public string ReferenceKey2 { get; set; }
        public string ReferenceKey3 { get; set; }
        //[RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "ToNumber must be numeric.")]
        [StringLength(maximumLength: 11, MinimumLength = 10, ErrorMessage = "ToNumber must be 10-11 characters")]
        public string ToNumber { get; set; }
        [Required(ErrorMessage = "Message is required.")]
        [StringLength(500, MinimumLength = 10, ErrorMessage = "Message required 10-500 characters")]
        public string Message { get; set; }
        public string ResultTrackingID { get; set; }
        public string ResultContent { get; set; }
        public DateTime CreateDate { get; set; }

        public bool IsSend { get; set; }
        public DateTime? SendDateTime { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }
    }

}
