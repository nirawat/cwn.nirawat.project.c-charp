﻿using CWN.Service.Sms.Models.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CWN.Service.Sms.Entities.CWN_ServiceSms
{
    [Table("Sms_Job_Log")]
    public class Sms_Job_Log
    {
        [Key]
        public int Id { get; set; }
        public int JobId { get; set; }
        public string LogEvent { get; set; }
        public string LogContent { get; set; }
        public DateTime LogDate { get; set; }
    }

}
