﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CWN.Service.Sms.Entities.CWN_ServiceSms
{
    [Table("Sms_Tracking")]
    public class Sms_Tracking
    {
        [Key]
        public int Id { get; set; }
        public int SendId { get; set; }
        [Required(ErrorMessage = "JobId is required.")]
        public int JobId { get; set; }
        public DateTime? SendDateTime { get; set; }
        public string TrackingID { get; set; }
        public string TrackingResult { get; set; }
        public DateTime? TrackingDate { get; set; }
        public DateTime CreateDate { get; set; }
    }

}
