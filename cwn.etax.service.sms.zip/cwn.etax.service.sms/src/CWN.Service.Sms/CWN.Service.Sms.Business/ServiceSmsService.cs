﻿using CWN.Service.Sms.Business.Interfaces;
using CWN.Service.Sms.Entities.CWN_ServiceSms;
using CWN.Service.Sms.Helpers;
using CWN.Service.Sms.Models.Response;
using CWN.Service.Sms.Repository.Interfaces;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace CWN.Service.Sms.Business
{
    public class ServiceSmsService : IServiceSmsService
    {
        private readonly IServiceSmsRepository _ServiceSmsRepository;
        private readonly IIntersectsTime _IIntersectsTime;

        public ServiceSmsService(IServiceSmsRepository ServiceSmsRepository, IIntersectsTime IIntersectsTimes)
        {
            _ServiceSmsRepository = ServiceSmsRepository;
            _IIntersectsTime = IIntersectsTimes;
        }

        public async Task<SendSmsResponse> Sms_Send(Sms_Send model, SmsMailBit_MessageResponse result)
        {
            SendSmsResponse resp = new SendSmsResponse();

            resp.status = false;
            resp.trackingID = string.Empty;
            resp.description = (result.ErrorMessage == null) ? string.Empty : result.ErrorMessage;

            if (model.IsSend)
            {
                if (result.ErrorCode == "000") // Success
                {
                    model.ResultTrackingID = result.MessageData[0].MessageParts[0].MsgId;
                    model.ResultContent = JsonConvert.SerializeObject(result);
                    model.CreateDate = _IIntersectsTime.DateNowTimeZone();
                }
            }

            int trackID = await _ServiceSmsRepository.Sms_Send(model);
            resp.trackingID = model.ResultTrackingID;
            resp.description = (result.ErrorMessage == null) ? "In Process..." : result.ErrorMessage;
            resp.status = (trackID > 0) ? true : false;

            return resp;

        }

        public async Task<bool> UpdateTrackingAsync(string TrackingID, string ResultContent)
        {
            return await _ServiceSmsRepository.UpdateTrackingAsync(TrackingID, ResultContent);
        }

    }
}
