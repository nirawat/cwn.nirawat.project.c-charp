﻿namespace CWN.Service.Sms.RobotTask.Configs
{
    public interface IRobotConfig
    {
        int SendProcess { get; set; }
        int TrackingProcess { get; set; }
        int SendDelay { get; set; }
        int TrackingDelay { get; set; }
    }

    public class RobotConfig : IRobotConfig
    {
        public int SendProcess { get; set; }
        public int TrackingProcess { get; set; }
        public int SendDelay { get; set; }
        public int TrackingDelay { get; set; }
    }
}
