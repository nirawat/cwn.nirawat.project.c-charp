using CWN.Service.Sms.RobotTask.Configs;
using CWN.Service.Sms.RobotTask.Model;
using CWN.Service.Sms.RobotTask.SendJobServices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using System.Globalization;

namespace CWN.ETax.Provider.RobotTask
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<SmsMailBitConfig>(Configuration.GetSection(nameof(SmsMailBitConfig)));
            services.AddSingleton<ISmsMailBitConfig>(sp => sp.GetRequiredService<IOptions<SmsMailBitConfig>>().Value);

            services.Configure<RobotConfig>(Configuration.GetSection(nameof(RobotConfig)));
            services.AddSingleton<IRobotConfig>(sp => sp.GetRequiredService<IOptions<RobotConfig>>().Value);

            services.AddHttpClient();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            var cultureInfo = new CultureInfo("en-GB");
            CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            //Activate Repository
            #region RobotTask Send Jobs Service
            services.AddHostedService<RobotServiceSendJob>();
            #endregion

            #region Background Queued
            services.AddHostedService<QueuedHostedServiceSendJob>();
            services.AddSingleton<IBackgroundTaskQueueSendJob, BackgroundTaskQueueSendJob>();
            #endregion

            //End
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
