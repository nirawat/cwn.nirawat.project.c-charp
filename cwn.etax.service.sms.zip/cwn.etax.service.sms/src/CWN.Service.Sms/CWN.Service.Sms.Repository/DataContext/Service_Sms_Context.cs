﻿using CWN.Service.Sms.Entities.CWN_ServiceSms;
using Microsoft.EntityFrameworkCore;

namespace CWN.Service.Sms.Repository.DataContext
{
    public class Service_Sms_Context : DbContext
    {
        public Service_Sms_Context(DbContextOptions<Service_Sms_Context> options) : base(options)
        {
        }

        public DbSet<MST_Register> MST_Registers { get; set; }
        public DbSet<Sms_Tracking> Sms_Trackings { get; set; }
        public DbSet<Sms_Job> Sms_Jobs { get; set; }

    }
}
