﻿using CWN.Service.Sms.Entities.CWN_ServiceSms;
using CWN.Service.Sms.Helpers;
using CWN.Service.Sms.Repository.DataContext;
using CWN.Service.Sms.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWN.Service.Sms.Repository
{
    public class ServiceSmsRepository : IServiceSmsRepository
    {
        private readonly IConfiguration _configuration;
        private readonly Service_Sms_Context _Service_Sms_Context;
        private readonly string ConnectionString;
        private readonly IIntersectsTime _IIntersectsTime;
        public ServiceSmsRepository(IConfiguration configuration,
            Service_Sms_Context Service_Sms_Contexts,
            IIntersectsTime IIntersectsTimes)
        {
            _configuration = configuration;
            _Service_Sms_Context = Service_Sms_Contexts;
            _IIntersectsTime = IIntersectsTimes;
            ConnectionString = Encoding.UTF8.GetString(Convert.FromBase64String(_configuration.GetConnectionString("dbServiceSms")));
        }

        public async Task<int> Sms_Send(Sms_Send model)
        {
            int trackID = 0;
            string sp_name = "sp_Sms_Send";

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                await conn.OpenAsync();
                using (SqlCommand cmd = new SqlCommand(sp_name, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@SenderId", SqlDbType.VarChar, 11).Value = model.SenderId;
                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = _IIntersectsTime.DateNowTimeZone();
                    cmd.Parameters.Add("@isSend", SqlDbType.Bit).Value = model.IsSend;
                    cmd.Parameters.Add("@ReferenceKey1", SqlDbType.VarChar, 100).Value = ParseDataHelper.ConvertDBNull(model.ReferenceKey);
                    cmd.Parameters.Add("@ReferenceKey2", SqlDbType.VarChar, 100).Value = ParseDataHelper.ConvertDBNull(model.ReferenceKey2);
                    cmd.Parameters.Add("@ReferenceKey3", SqlDbType.VarChar, 100).Value = ParseDataHelper.ConvertDBNull(model.ReferenceKey3);
                    cmd.Parameters.Add("@SendDateTime", SqlDbType.DateTime).Value = ParseDataHelper.ConvertDBNullDate(model.SendDateTime);
                    cmd.Parameters.Add("@StartTime", SqlDbType.Time, 7).Value = ParseDataHelper.ConvertDBNullTime(model.StartTime);
                    cmd.Parameters.Add("@EndTime", SqlDbType.Time, 7).Value = ParseDataHelper.ConvertDBNullTime(model.EndTime);
                    cmd.Parameters.Add("@FromName", SqlDbType.VarChar, 100).Value = model.SenderId;
                    cmd.Parameters.Add("@ToNumber", SqlDbType.VarChar, 11).Value = model.ToNumber;
                    cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500).Value = model.Message;
                    cmd.Parameters.Add("@ResultTrackingID", SqlDbType.VarChar, 200).Value = ParseDataHelper.ConvertDBNull(model.ResultTrackingID);
                    cmd.Parameters.Add("@ResultContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(model.ResultContent);

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;

                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    SqlParameter rTrackID = cmd.Parameters.Add("@rTrackID", SqlDbType.Int);
                    rTrackID.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();

                    trackID = Convert.ToInt32(cmd.Parameters["@rTrackID"].Value);

                }
                conn.Close();
            }
            return trackID;
        }

        public async Task<IList<Sms_Job>> GetAll_Jobs()
        {
            DateTime dtnow = _IIntersectsTime.DateNowTimeZone();

            return await _Service_Sms_Context.Sms_Jobs.Where(e => (e.StartTime <= dtnow.TimeOfDay && e.EndTime >= dtnow.TimeOfDay)).ToListAsync();

        }

        public async Task<bool> UpdateTrackingAsync(string TrackingID, string ResultContent)
        {
            bool result = false;

            DateTime dtnow = _IIntersectsTime.DateNowTimeZone();

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                await conn.OpenAsync();
                using (SqlCommand cmd = new SqlCommand("sp_Sms_Tracking", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@TrackingID", SqlDbType.VarChar, 100).Value = TrackingID;
                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = dtnow;
                    cmd.Parameters.Add("@ResultContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(ResultContent);

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;

                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();

                    result = ((int)(cmd.Parameters["@rStatus"].Value) >= 1) ? true : false;

                }
                conn.Close();
                conn.Dispose();
            }
            return result;
        }


    }
}
