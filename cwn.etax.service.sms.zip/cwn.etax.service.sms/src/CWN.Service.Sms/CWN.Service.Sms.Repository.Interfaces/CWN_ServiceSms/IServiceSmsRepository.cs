﻿using CWN.Service.Sms.Entities.CWN_ServiceSms;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CWN.Service.Sms.Repository.Interfaces
{
    public interface IServiceSmsRepository
    {
        Task<int> Sms_Send(Sms_Send model);
        Task<IList<Sms_Job>> GetAll_Jobs();
        Task<bool> UpdateTrackingAsync(string TrackingID, string ResultContent);
    }
}
