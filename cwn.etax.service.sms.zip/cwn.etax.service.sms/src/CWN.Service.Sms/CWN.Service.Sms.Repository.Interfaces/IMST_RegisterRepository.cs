﻿using CWN.Service.Sms.Entities.CWN_ServiceSms;
using System.Threading.Tasks;

namespace CWN.Service.Sms.Repository.Interfaces
{
    public interface IMST_RegisterRepository
    {
        Task<string> RegisterUser(MST_Register model);
        Task<string> UpdateInformation(MST_Register model);
        Task<string> GetToken(MST_Register model);
        Task<bool> ValidateTokenKey(string TokenKey);
    }
}
