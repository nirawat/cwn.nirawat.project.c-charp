﻿using CWN.Service.Sms.Entities.CWN_ServiceSms;
using CWN.Service.Sms.Models.Response;
using System.Threading.Tasks;

namespace CWN.Service.Sms.Business.Interfaces
{
    public interface IServiceSmsService
    {
        Task<SendSmsResponse> Sms_Send(Sms_Send model, SmsMailBit_MessageResponse result);
        Task<bool> UpdateTrackingAsync(string TrackingID, string ResultContent);
    }
}
