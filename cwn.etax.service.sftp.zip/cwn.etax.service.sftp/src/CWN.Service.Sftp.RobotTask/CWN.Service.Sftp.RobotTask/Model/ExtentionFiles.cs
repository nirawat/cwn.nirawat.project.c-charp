﻿namespace CWN.Service.Sftp.RobotTask.Model
{
    public class AllowSynchronous
    {
        public string[] AllowReceiptTaxInvoice { get; set; } = new[] { "T03-" };
        public string[] AllowAbbTaxInvoice { get; set; } = new[] { "T06-" };
        public string[] AllowDebitNote { get; set; } = new[] { "80-" };
        public string[] AllowCreditNote { get; set; } = new[] { "81-" };
    }

    public class AllowProcess
    {
        public string[] AllowReceiptTaxInvoice { get; set; } = new[] { "T03-" };
        public string[] AllowAbbTaxInvoice { get; set; } = new[] { "T06-" };
        public string[] AllowDebitNote { get; set; } = new[] { "80-" };
        public string[] AllowCreditNote { get; set; } = new[] { "81-" };
    }

    public class AllowExtentionFiles
    {
        public string[] allow_sftp { get; set; } = new[] { ".csv", ".txt" };
        public string[] allow_process { get; set; } = new[] { ".etax" };
        public string allow_backup { get; set; } = ".bak";
        public string allow_token_err { get; set; } = "_token.err";
        public string allow_transfer_err { get; set; } = "_transfer.err";
        public string allow_format_err { get; set; } = "_format.err";
        public string allow_template_err { get; set; } = "_template.err";
    }

    public class StoreProcedureName
    {
        public string sp_receipttaxinvoice { get; set; } = "sp_sftp_logs_receipt_tax_invoice";
        public string sp_abbtaxinvoice { get; set; } = "sp_sftp_logs_abb_tax_invoice";
        public string sp_creditnote { get; set; } = "sp_sftp_logs_credit_note";
        public string sp_debitnote { get; set; } = "sp_sftp_logs_debit_note";
    }

}
