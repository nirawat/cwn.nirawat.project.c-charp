﻿namespace CWN.Service.Sftp.RobotTask.Model
{
    public class Enumeration
    {
        public enum ErrorType
        {
            ErrorToken = 0,
            ErrorFormat = 1,
            ErrorTemplate = 2,
            ErrorTransfer = 3,
        }
    }

}
