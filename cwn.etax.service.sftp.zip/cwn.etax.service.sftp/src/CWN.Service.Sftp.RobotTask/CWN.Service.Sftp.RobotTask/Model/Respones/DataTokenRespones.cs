﻿namespace CWN.Service.Sftp.RobotTask.Models.Respones
{
    public class DataTokenRespones
    {
        public bool Status { get; set; }
        public string Message { get; set; }
        public BatchKeyRespones BatchKey { get; set; }
    }
}
