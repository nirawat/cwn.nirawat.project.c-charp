﻿namespace CWN.Service.Sftp.RobotTask.Models.Respones
{
    public class BatchKeyRespones
    {
        public int CorporateID { get; set; }
        public int CompanyID { get; set; }
        public int BranchID { get; set; }
    }
}
