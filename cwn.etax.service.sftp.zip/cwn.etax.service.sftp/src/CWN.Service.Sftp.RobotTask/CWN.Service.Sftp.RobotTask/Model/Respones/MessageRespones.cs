﻿using System.Collections.Generic;

namespace CWN.Service.Sftp.RobotTask.Models.Respones
{
    public class MessageRespones
    {
        public bool Status { get; set; }
        public string Message { get; set; } = "";
    }
    public class MessageAddDocRespones
    {
        public bool Status { get; set; }
        public string Message { get; set; } = "";
        public int DocId { get; set; }
    }

    public class MessageValidateDataRespones
    {
        public bool Status { get; set; }
        public string Message { get; set; } = "";
        public IList<MessageValidateDataItemsRespones> MessageItems { get; set; }
    }

    public class MessageValidateDataItemsRespones
    {
        public string Message { get; set; } = "";
    }
}
