﻿using CWN.Service.Sftp.RobotTask.Model.FileReceive.AbbTaxInvoice.Resource;
using CWN.Service.Sftp.RobotTask.Model.FileReceive.CreditNote.Resource;
using CWN.Service.Sftp.RobotTask.Model.FileReceive.DebitNote.Resource;
using CWN.Service.Sftp.RobotTask.Model.FileReceive.ReceiptTaxInvoice.Resource;
using System.Collections.Generic;

namespace CWN.Service.Sftp.RobotTask.Model.FileReceive
{
    public class FileData
    {
        public string SourceFile { get; set; }
        public string FileName { get; set; }
        public string FileNameWithoutExtension { get; set; }
        public string TokenKey { get; set; }
        public string DataContent { get; set; }
        public string ErrorContent { get; set; }
        public int ErrorCount { get; set; }
        public IList<FileContent_ReceiptTaxInvoice_Resource> List_ReceiptTaxInvoice { get; set; }
        public IList<FileContent_AbbTaxInvoice_Resource> List_AbbTaxInvoice { get; set; }
        public IList<FileContent_DebitNote_Resource> List_DebitNote { get; set; }
        public IList<FileContent_CreditNote_Resource> List_CreditNote { get; set; }

    }

    public class FileContent_ReceiptTaxInvoice_Resource
    {
        public DocReceiptTaxInvoiceResource Documents { get; set; }
        public string DataContent { get; set; }
        public string ErrorContent { get; set; }
    }

    public class FileContent_AbbTaxInvoice_Resource
    {
        public DocAbbTaxInvoiceResource Documents { get; set; }
        public string DataContent { get; set; }
        public string ErrorContent { get; set; }
    }

    public class FileContent_DebitNote_Resource
    {
        public DocDebitNoteResource Documents { get; set; }
        public string DataContent { get; set; }
        public string ErrorContent { get; set; }
    }

    public class FileContent_CreditNote_Resource
    {
        public DocCreditNoteResource Documents { get; set; }
        public string DataContent { get; set; }
        public string ErrorContent { get; set; }
    }


}
