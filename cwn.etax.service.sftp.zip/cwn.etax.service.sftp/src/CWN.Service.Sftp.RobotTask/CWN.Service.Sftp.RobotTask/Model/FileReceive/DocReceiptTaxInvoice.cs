﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace CWN.Service.Sftp.RobotTask.Model.FileReceive.ReceiptTaxInvoice.Resource
{
    public class DocReceiptTaxInvoiceResource
    {
        // Company ---------------------------
        public int CorporateId { get; set; }
        public int CompanyId { get; set; }
        public int BranchId { get; set; }
        // -----------------------------------

        public string DocumentCode { get; set; } = "T03";
        [Required(ErrorMessage = "Language is required.")]
        public string DocumentLanguage { get; set; }
        [Required(ErrorMessage = "Document number is required.")]
        public string DocumentNumber { get; set; }
        [Required(ErrorMessage = "Document date is required.")]
        public DateTime DocumentDate { get; set; }
        [Required(ErrorMessage = "Activity date is required.")]
        public DateTime? ActivityDate { get; set; }
        [Required(ErrorMessage = "Payment channel is required.")]
        public string PaymentChannel { get; set; }
        public string PaymentAccountNo { get; set; }
        public string PaymentOtherChannel​ { get; set; }
        public string Password { get; set; }
        [Required(ErrorMessage = "Sealer is required.")]
        public bool IsSealer { get; set; }
        [Required(ErrorMessage = "Realtime is required.")]
        public bool IsRealtime { get; set; }
        [Required(ErrorMessage = "Send to customer is required.")]
        public bool IsSendToCust { get; set; }
        [Required(ErrorMessage = "Total amount is required.")]
        public decimal TotalAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        [Required(ErrorMessage = "Vat rate is required.")]
        public decimal VatRate { get; set; }
        [Required(ErrorMessage = "Vate amount is required.")]
        public decimal VatAmount { get; set; }
        [Required(ErrorMessage = "Net amount is required.")]
        public decimal NetAmount { get; set; }

        [Required(ErrorMessage = "UseDocAddForMailing is required.")]
        public bool UseDocAddForMailing { get; set; }
        public string OriginalDocumentNumber { get; set; }
        [RequiredOgirinalDocumentDateAttribute()]
        public DateTime? OriginalDocumentDate { get; set; }
        [RequiredAdditionalReferencedDocumentAttribute()]
        public string AdditionalReferencedDocument { get; set; }
        [RequiredReasonCodeAttribute()]
        public string ReasonCode { get; set; }
        public string ReasonDesc { get; set; }
        public decimal WHTTotalAmount { get; set; }
        public string Remark { get; set; }

        public DocReceiptTaxInvoicePayeeSignatureResource PayeeSignature { get; set; }
        public DocReceiptTaxInvoicePayerSignatureResource PayerSignature { get; set; }

        [RequiredBuyerDataAttribute()]
        public DocReceiptTaxInvoiceBuyerResource Buyer { get; set; }
        [RequiredMailingAddressDataAttribute()]
        public DocReceiptTaxInvoiceMailingAddressResource MailingAddress { get; set; }
        [RequiredSendChannelDataAttribute()]
        public IList<DocReceiptTaxInvoiceSendInformationResource> ItemSendChannel { get; set; }
        [RequiredItemDescriptionAttribute()]
        public IList<DocReceiptTaxInvoiceDetailResource> ItemDetail { get; set; }
        [RequiredItemWithholdingTaxAttribute()]
        public IList<DocReceiptTaxInvoiceWithholdingTaxResource> WHTItemDescription { get; set; }
        [RequiredItemMessageAttribute()]
        public IList<DocReceiptTaxInvoiceMessageResource> ItemMessage { get; set; }

    }
    public class DocReceiptTaxInvoiceBuyerResource
    {
        [Required(ErrorMessage = "Type is required.")]
        public string BuyerType { get; set; }
        public string IndividualType { get; set; }
        public string IdentificationType { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Identification number must be numeric")]
        public string IdentificationNo { get; set; }
        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }
        public string TaxId { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Branch name must be numeric")]
        public string BranchName { get; set; }
        [Required(ErrorMessage = "Building number is required.")]
        public string BuildingNumber { get; set; }
        public string BuildingName { get; set; }
        public string Moo { get; set; }
        public string RoomNo { get; set; }
        public string Floor { get; set; }
        public string Soi { get; set; }
        public string SubSoi { get; set; }
        public string StreetName { get; set; }
        public string Tumbol { get; set; }
        [Required(ErrorMessage = "Amphur is required.")]
        public string Amphur { get; set; }
        [Required(ErrorMessage = "Province is required.")]
        public string Province { get; set; }
        [Required(ErrorMessage = "Country ID is required.")]
        public string CountryID { get; set; }
        [Required(ErrorMessage = "Postal code is required.")]
        public string PostCode { get; set; }
    }
    public class DocReceiptTaxInvoiceDetailResource
    {
        public int Seq { get; set; }
        [Required(ErrorMessage = "Item description is required.")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Item Quantity is required.")]
        public decimal Qty { get; set; }
        [Required(ErrorMessage = "Item Unit is required.")]
        public string Unit { get; set; }
        [Required(ErrorMessage = "Item sale price is required.")]
        public decimal SalePrice { get; set; }
        public decimal DiscountAmount { get; set; }
        [Required(ErrorMessage = "Item amount is required.")]
        public decimal Amount { get; set; }
    }
    public class DocReceiptTaxInvoiceMailingAddressResource
    {
        public string Name { get; set; }
        public string TaxId { get; set; }
        public string BranchName { get; set; }
        public string BuildingNumber { get; set; }
        public string BuildingName { get; set; }
        public string Moo { get; set; }
        public string RoomNo { get; set; }
        public string Floor { get; set; }
        public string Soi { get; set; }
        public string SubSoi { get; set; }
        public string StreetName { get; set; }
        public string Tumbol { get; set; }
        public string Amphur { get; set; }
        public string Province { get; set; }
        public string CountryID { get; set; }
        public string PostCode { get; set; }
    }
    public class DocReceiptTaxInvoiceMessageResource
    {
        public int Seq { get; set; }
        public string Message { get; set; }
    }
    public class DocReceiptTaxInvoiceSendInformationResource
    {
        public int Seq { get; set; }
        public string SendType { get; set; }
        public string SendTo { get; set; }
    }
    public class DocReceiptTaxInvoicePayeeSignatureResource
    {
        public string PayeeSignatureCode { get; set; }
        public string PayeeSignatureName { get; set; }
        public string PayeeSignatureRole { get; set; }
        public string PayeeSignatureBase64 { get; set; }
        public string PayeeSignatureExtension { get; set; }
        public string PayeeSignatureFileName { get; set; }
        public DateTime? PayeeSignatureDate { get; set; }
    }
    public class DocReceiptTaxInvoicePayerSignatureResource
    {
        public string PayerSignatureCode { get; set; }
        public string PayerSignatureName { get; set; }
        public string PayerSignatureRole { get; set; }
        public string PayerSignatureBase64 { get; set; }
        public string PayerSignatureExtension { get; set; }
        public string PayerSignatureFileName { get; set; }
        public DateTime? PayerSignatureDate​ { get; set; }
    }
    public class DocReceiptTaxInvoiceWithholdingTaxResource
    {
        public int Seq { get; set; }
        public string WHTDescription { get; set; }
        public Decimal WHTRate { get; set; }
        public Decimal WHTAmount { get; set; }
    }

    #region Validate Require

    public class RequiredOgirinalDocumentDateAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (!string.IsNullOrWhiteSpace(model.OriginalDocumentNumber) && model.OriginalDocumentDate == null)
            {
                return new ValidationResult("Original document date is requried.", membername);
            }
            if (string.IsNullOrWhiteSpace(model.OriginalDocumentNumber) && model.OriginalDocumentDate != null)
            {
                return new ValidationResult("Original document date is required original document number.", membername);
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredAdditionalReferencedDocumentAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (!string.IsNullOrWhiteSpace(model.OriginalDocumentNumber) && string.IsNullOrWhiteSpace(model.AdditionalReferencedDocument))
            {
                return new ValidationResult("AdditionalReferencedDocument is requried.", membername);
            }
            if (string.IsNullOrWhiteSpace(model.OriginalDocumentNumber) && !string.IsNullOrWhiteSpace(model.AdditionalReferencedDocument))
            {
                return new ValidationResult("Additional referenced document is required original document number.", membername);
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredReasonCodeAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (!string.IsNullOrWhiteSpace(model.OriginalDocumentNumber) && string.IsNullOrWhiteSpace(model.ReasonCode))
            {
                return new ValidationResult("Reason code is require.", membername);
            }
            if (string.IsNullOrWhiteSpace(model.OriginalDocumentNumber) && !string.IsNullOrWhiteSpace(model.ReasonCode))
            {
                return new ValidationResult("Reason code is required original document number.", membername);
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredBuyerDataAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.Buyer == null)
            {
                return new ValidationResult("Buyer data is requried.", membername);
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredMailingAddressDataAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.UseDocAddForMailing == false)
            {
                if (model.MailingAddress == null)
                {
                    return new ValidationResult("Mailing address data is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.Name))
                {
                    return new ValidationResult("Mailing name is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.BuildingNumber))
                {
                    return new ValidationResult("Mailing building number is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.CountryID))
                {
                    return new ValidationResult("Mailing country id is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.PostCode))
                {
                    return new ValidationResult("Mailing postal code is requried.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredSendChannelDataAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.ItemSendChannel == null || model.ItemSendChannel.Count <= 0)
            {
                return new ValidationResult("Item Send to is required.", membername);
            }
            if (model.ItemSendChannel != null && model.ItemSendChannel.Count >= 0)
            {
                foreach (var _x_ in model.ItemSendChannel)
                {
                    if (string.IsNullOrWhiteSpace(_x_.SendType))
                    {
                        return new ValidationResult("Send type is require '", membername);
                    }
                }
            }
            if (model.ItemSendChannel != null && model.ItemSendChannel.Count > 0)
            {
                if (model.ItemSendChannel.Count(e => e.Seq <= 0) > 0)
                {
                    return new ValidationResult("Sequence is require.", membername);
                }
                var group_seq = from e in model.ItemSendChannel
                                group e by e.Seq into g
                                select new { Key = g.Key, Count = g.Count() };
                if (group_seq.Count(e => e.Count > 1) > 0)
                {
                    return new ValidationResult("Sequence is duplicate.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredItemDescriptionAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.ItemDetail == null || model.ItemDetail.Count <= 0)
            {
                return new ValidationResult("Item detail is requried.", membername);
            }
            if (model.ItemDetail != null && model.ItemDetail.Count > 0)
            {
                if (model.ItemDetail.Count(e => e.Seq <= 0) > 0)
                {
                    return new ValidationResult("Sequence is require.", membername);
                }
                var group_seq = from e in model.ItemDetail
                                group e by e.Seq into g
                                select new { Key = g.Key, Count = g.Count() };
                if (group_seq.Count(e => e.Count > 1) > 0)
                {
                    return new ValidationResult("Sequence is duplicate.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredItemMessageAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.ItemMessage != null && model.ItemMessage.Count > 0)
            {
                if (model.ItemMessage.Count(e => e.Seq <= 0) > 0)
                {
                    return new ValidationResult("Sequence is require.", membername);
                }
                var group_seq = from e in model.ItemMessage
                                group e by e.Seq into g
                                select new { Key = g.Key, Count = g.Count() };
                if (group_seq.Count(e => e.Count > 1) > 0)
                {
                    return new ValidationResult("Sequence is duplicate.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredItemWithholdingTaxAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocReceiptTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.WHTItemDescription == null || model.WHTItemDescription.Count <= 0)
            {
                return new ValidationResult("Item WithholdingTax is requried.", membername);
            }
            if (model.WHTItemDescription != null && model.WHTItemDescription.Count > 0)
            {
                if (model.WHTItemDescription.Count(e => e.Seq <= 0) > 0)
                {
                    return new ValidationResult("Sequence is require.", membername);
                }
                var group_seq = from e in model.WHTItemDescription
                                group e by e.Seq into g
                                select new { Key = g.Key, Count = g.Count() };
                if (group_seq.Count(e => e.Count > 1) > 0)
                {
                    return new ValidationResult("Sequence is duplicate.", membername);
                }
            }
            return ValidationResult.Success;
        }

    }

    #endregion

}
