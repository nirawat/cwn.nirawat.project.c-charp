﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace CWN.Service.Sftp.RobotTask.Model.FileReceive.AbbTaxInvoice.Resource
{

    public class DocAbbTaxInvoiceResource
    {
        // Company ---------------------------
        public int CorporateId { get; set; }
        public int CompanyId { get; set; }
        public int BranchId { get; set; }
        // -----------------------------------

        public string DocumentCode { get; set; } = "T06";
        [Required(ErrorMessage = "Language is required.")]
        public string DocumentLanguage { get; set; }
        [Required(ErrorMessage = "Document number is required.")]
        public string DocumentNumber { get; set; }
        [Required(ErrorMessage = "Document date is required.")]
        public DateTime DocumentDate { get; set; }
        [Required(ErrorMessage = "Activity date is required.")]
        public DateTime? ActivityDate { get; set; }
        [Required(ErrorMessage = "Payment channel is required.")]
        public string PaymentChannel { get; set; }
        public string PaymentAccountNo { get; set; }
        public string PaymentOtherChannel​ { get; set; }
        public string Password { get; set; }
        [Required(ErrorMessage = "Sealer is required.")]
        public bool IsSealer { get; set; }
        [Required(ErrorMessage = "Realtime is required.")]
        public bool IsRealtime { get; set; }
        [Required(ErrorMessage = "Send to customer is required.")]
        public bool IsSendToCust { get; set; }
        [Required(ErrorMessage = "Total amount is required.")]
        public decimal TotalAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        [Required(ErrorMessage = "Vat rate is required.")]
        public decimal VatRate { get; set; }
        [Required(ErrorMessage = "Vate amount is required.")]
        public decimal VatAmount { get; set; }
        [Required(ErrorMessage = "Net amount is required.")]
        public decimal NetAmount { get; set; }

        [Required(ErrorMessage = "UseDocAddForMailing is required.")]
        public bool UseDocAddForMailing { get; set; }

        [RequiredBuyerDataAttribute()]
        public DocAbbBuyerResource Buyer { get; set; }
        [RequiredMailingAddressDataAttribute()]
        public DocAbbMailingAddressResource MailingAddress { get; set; }
        [RequiredSendChannelDataAttribute()]
        public IList<DocAbbSendInformationResource> ItemSendChannel { get; set; }
        [RequiredItemDescriptionAttribute()]
        public IList<DocAbbDetailResource> ItemDetail { get; set; }
        [RequiredItemMessageAttribute()]
        public IList<DocAbbMessageResource> ItemMessage { get; set; }
    }
    public class DocAbbBuyerResource
    {
        [Required(ErrorMessage = "Type is required.")]
        public string BuyerType { get; set; }
        public string IndividualType { get; set; }
        public string IdentificationType { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Identification number must be numeric")]
        public string IdentificationNo { get; set; }
        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }
        public string TaxId { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Branch name must be numeric")]
        public string BranchName { get; set; }
        [Required(ErrorMessage = "Building number is required.")]
        public string BuildingNumber { get; set; }
        public string BuildingName { get; set; }
        public string Moo { get; set; }
        public string RoomNo { get; set; }
        public string Floor { get; set; }
        public string Soi { get; set; }
        public string SubSoi { get; set; }
        public string StreetName { get; set; }
        public string Tumbol { get; set; }
        [Required(ErrorMessage = "Amphur is required.")]
        public string Amphur { get; set; }
        [Required(ErrorMessage = "Province is required.")]
        public string Province { get; set; }
        [Required(ErrorMessage = "Country ID is required.")]
        public string CountryID { get; set; }
        [Required(ErrorMessage = "Postal code is required.")]
        public string PostCode { get; set; }
    }
    public class DocAbbDetailResource
    {
        public int Seq { get; set; }
        [Required(ErrorMessage = "Item description is required.")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Item Quantity is required.")]
        public decimal Qty { get; set; }
        [Required(ErrorMessage = "Item Unit is required.")]
        public string Unit { get; set; }
        [Required(ErrorMessage = "Item sale price is required.")]
        public decimal SalePrice { get; set; }
        public decimal DiscountAmount { get; set; }
        [Required(ErrorMessage = "Item amount is required.")]
        public decimal Amount { get; set; }
    }
    public class DocAbbMailingAddressResource
    {
        public string Name { get; set; }
        public string TaxId { get; set; }
        public string BranchName { get; set; }
        public string BuildingNumber { get; set; }
        public string BuildingName { get; set; }
        public string Moo { get; set; }
        public string RoomNo { get; set; }
        public string Floor { get; set; }
        public string Soi { get; set; }
        public string SubSoi { get; set; }
        public string StreetName { get; set; }
        public string Tumbol { get; set; }
        public string Amphur { get; set; }
        public string Province { get; set; }
        public string CountryID { get; set; }
        public string PostCode { get; set; }
    }
    public class DocAbbMessageResource
    {
        public int Seq { get; set; }
        public string Message { get; set; }
    }
    public class DocAbbSendInformationResource
    {
        public int Seq { get; set; }
        public string SendType { get; set; }
        public string SendTo { get; set; }
    }


    #region Validate Require

    public class RequiredBuyerDataAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocAbbTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.Buyer == null)
            {
                return new ValidationResult("Buyer data is requried.", membername);
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredMailingAddressDataAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocAbbTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.UseDocAddForMailing == false)
            {
                if (model.MailingAddress == null)
                {
                    return new ValidationResult("Mailing address data is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.Name))
                {
                    return new ValidationResult("Mailing name is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.BuildingNumber))
                {
                    return new ValidationResult("Mailing building number is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.CountryID))
                {
                    return new ValidationResult("Mailing country id is requried.", membername);
                }
                if (string.IsNullOrWhiteSpace(model.MailingAddress.PostCode))
                {
                    return new ValidationResult("Mailing postal code is requried.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredSendChannelDataAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocAbbTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.ItemSendChannel == null || model.ItemSendChannel.Count <= 0)
            {
                return new ValidationResult("Item Send to is required.", membername);
            }
            if (model.ItemSendChannel != null && model.ItemSendChannel.Count >= 0)
            {
                foreach (var _x_ in model.ItemSendChannel)
                {
                    if (string.IsNullOrWhiteSpace(_x_.SendType))
                    {
                        return new ValidationResult("Send type is require '", membername);
                    }
                }
            }
            if (model.ItemSendChannel != null && model.ItemSendChannel.Count > 0)
            {
                if (model.ItemSendChannel.Count(e => e.Seq <= 0) > 0)
                {
                    return new ValidationResult("Sequence is require.", membername);
                }
                var group_seq = from e in model.ItemSendChannel
                                group e by e.Seq into g
                                select new { Key = g.Key, Count = g.Count() };
                if (group_seq.Count(e => e.Count > 1) > 0)
                {
                    return new ValidationResult("Sequence is duplicate.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredItemDescriptionAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocAbbTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.ItemDetail == null || model.ItemDetail.Count <= 0)
            {
                return new ValidationResult("Item detail is requried.", membername);
            }
            if (model.ItemDetail != null && model.ItemDetail.Count > 0)
            {
                if (model.ItemDetail.Count(e => e.Seq <= 0) > 0)
                {
                    return new ValidationResult("Sequence is require.", membername);
                }
                var group_seq = from e in model.ItemDetail
                                group e by e.Seq into g
                                select new { Key = g.Key, Count = g.Count() };
                if (group_seq.Count(e => e.Count > 1) > 0)
                {
                    return new ValidationResult("Sequence is duplicate.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }
    public class RequiredItemMessageAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (DocAbbTaxInvoiceResource)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.ItemMessage != null && model.ItemMessage.Count > 0)
            {
                if (model.ItemMessage.Count(e => e.Seq <= 0) > 0)
                {
                    return new ValidationResult("Sequence is require.", membername);
                }
                var group_seq = from e in model.ItemMessage
                                group e by e.Seq into g
                                select new { Key = g.Key, Count = g.Count() };
                if (group_seq.Count(e => e.Count > 1) > 0)
                {
                    return new ValidationResult("Sequence is duplicate.", membername);
                }
            }
            return ValidationResult.Success;
        }
    }

    #endregion

}
