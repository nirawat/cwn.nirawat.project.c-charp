using CWN.Service.Sftp.RobotTask.Business;
using CWN.Service.SFTP.RobotTask.ProcessServices;
using CWN.Service.SFTP.RobotTask.SyncServices;
using CWN.Service.Sms.RobotTask.Configs;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using System.Globalization;

namespace CWN.ETax.Provider.RobotTask
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {

            services.Configure<RobotConfig>(Configuration.GetSection(nameof(RobotConfig)));
            services.AddSingleton<IRobotConfig>(sp => sp.GetRequiredService<IOptions<RobotConfig>>().Value);

            services.Configure<ApiReceiveConfig>(Configuration.GetSection(nameof(ApiReceiveConfig)));
            services.AddSingleton<IApiReceiveConfig>(sp => sp.GetRequiredService<IOptions<ApiReceiveConfig>>().Value);

            services.AddHttpClient();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            var cultureInfo = new CultureInfo("en-GB");
            CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            #region RobotTask Synchronous
            services.AddSingleton<IHandleData, HandleData>();
            services.AddHostedService<RobotSyncReceiptTaxInvoice>();
            services.AddHostedService<RobotSyncAbbTaxInvoice>();
            services.AddHostedService<RobotSyncDebitNote>();
            services.AddHostedService<RobotSyncCreditNote>();
            #endregion

            #region Background Queued Synchronous
            services.AddHostedService<QueuedHostedServiceSync>();
            services.AddSingleton<IBackgroundTaskQueueSync, BackgroundTaskQueueSync>();
            #endregion

            #region Background Queued Process
            services.AddHostedService<QueuedHostedServiceProcess>();
            services.AddSingleton<IBackgroundTaskQueueProcess, BackgroundTaskQueueProcess>();
            #endregion

            #region RobotTask Process
            services.AddHostedService<RobotProcessReceiptTaxInvoice>();
            services.AddHostedService<RobotProcessAbbTaxInvoice>();
            services.AddHostedService<RobotProcessDebitNote>();
            services.AddHostedService<RobotProcessCreditNote>();
            #endregion

        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
