﻿using CWN.Service.Sftp.RobotTask.Model;
using CWN.Service.Sftp.RobotTask.Model.FileReceive;
using System.Threading.Tasks;

namespace CWN.Service.Sftp.RobotTask.Business
{
    public interface IHandleData
    {
        Task<bool> GetDirectory();

        Task<bool> SendDocument_ReceiptTaxInvoice_Async(FileData file_ftp);
        Task<bool> SendDocument_AbbTaxInvoice_Async(FileData file_ftp);
        Task<bool> SendDocument_CreditNote_Async(FileData file_ftp);
        Task<bool> SendDocument_DebitNote_Async(FileData file_ftp);

        Task<bool> SaveErrorLogFile_ReceiptTaxInvoice_Async(Enumeration.ErrorType error_type, FileData file_ftp);
        Task<bool> SaveErrorLogFile_AbbTaxInvoice_Async(Enumeration.ErrorType error_type, FileData file_ftp);
        Task<bool> SaveErrorLogFile_CreditNote_Async(Enumeration.ErrorType error_type, FileData file_ftp);
        Task<bool> SaveErrorLogFile_DebitNote_Async(Enumeration.ErrorType error_type, FileData file_ftp);

    }
}
