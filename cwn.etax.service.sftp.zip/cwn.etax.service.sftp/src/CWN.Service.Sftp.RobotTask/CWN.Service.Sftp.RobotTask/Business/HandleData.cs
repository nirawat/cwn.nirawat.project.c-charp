﻿using CWN.Service.Sftp.RobotTask.Model;
using CWN.Service.Sftp.RobotTask.Model.FileReceive;
using CWN.Service.Sms.Helpers;
using CWN.Service.Sms.RobotTask.ApiConnector;
using CWN.Service.Sms.RobotTask.Configs;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace CWN.Service.Sftp.RobotTask.Business
{
    public class HandleData : IHandleData
    {
        private static AllowExtentionFiles allowfile = new AllowExtentionFiles();
        private static StoreProcedureName storeprocedure = new StoreProcedureName();

        private static string _SqlDatabase;
        private static string _ProcessDirectory;
        private static string _BackupDirectory;
        private static string _ErrorDirectory;

        private IRobotConfig _robotconfig;
        private IApiReceiveConfig _apireceiveconfig;

        private static string url_api_base_ReceiptTaxInvoice;
        private static string url_api_base_AbbTaxInvoice;
        private static string url_api_base_CreditNote;
        private static string url_api_base_DebitNote;

        private static string url_api_receipttaxinvoice;
        private static string url_api_abbtaxinvoice;
        private static string url_api_creditnote;
        private static string url_api_debitnote;

        public HandleData(
            IRobotConfig robotconfig,
            IApiReceiveConfig apireceiveconfig)
        {
            _robotconfig = robotconfig;
            _apireceiveconfig = apireceiveconfig;

            _SqlDatabase = Encoding.UTF8.GetString(Convert.FromBase64String(_robotconfig.SqlDatabase));

            _BackupDirectory = Path.Combine(_robotconfig.SftpDirectory, _robotconfig.BackupDirectory, _robotconfig.RobotId);
            _ProcessDirectory = Path.Combine(_robotconfig.SftpDirectory, _robotconfig.ProcessDirectory, _robotconfig.RobotId);
            _ErrorDirectory = Path.Combine(_robotconfig.SftpDirectory, _robotconfig.ErrorDirectory, _robotconfig.RobotId);

            url_api_base_ReceiptTaxInvoice = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.BaseUrlReceiptTaxInvoice));
            url_api_base_AbbTaxInvoice = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.BaseUrlAbbTaxInvoice));
            url_api_base_CreditNote = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.BaseUrlCreditNote));
            url_api_base_DebitNote = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.BaseUrlDebitNote));

            url_api_receipttaxinvoice = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.UrlReceiptTaxInvoice));
            url_api_abbtaxinvoice = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.UrlAbbTaxInvoice));
            url_api_creditnote = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.UrlCreditNote));
            url_api_debitnote = Encoding.UTF8.GetString(Convert.FromBase64String(_apireceiveconfig.UrlDebitNote));
        }

        public async Task<bool> GetDirectory()
        {
            //if (!Directory.Exists(_SftpDirectory))
            //{
            //    DirectoryInfo dir = Directory.CreateDirectory(_SftpDirectory);
            //}
            //if (!Directory.Exists(_ProcessDirectory))
            //{
            //    DirectoryInfo dirBackup = Directory.CreateDirectory(_ProcessDirectory);
            //}
            //if (!Directory.Exists(_ErrorDirectory))
            //{
            //    DirectoryInfo dirError = Directory.CreateDirectory(_ErrorDirectory);
            //}

            return true;
        }

        #region Send Document to api
        public async Task<bool> SendDocument_ReceiptTaxInvoice_Async(FileData file_ftp)
        {
            int api_connection_error = 0;

            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                if (file_ftp.List_ReceiptTaxInvoice != null && file_ftp.List_ReceiptTaxInvoice.Count > 0)
                {
                    foreach (var docs in file_ftp.List_ReceiptTaxInvoice)
                    {
                        if (!string.IsNullOrEmpty(docs.Documents.DocumentNumber))
                        {
                            if (!string.IsNullOrEmpty(docs.ErrorContent))
                                // Save Error Log
                                await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, docs.ErrorContent, false, storeprocedure.sp_receipttaxinvoice, conn);
                            else
                            {
                                // Post log data
                                string requestUrl = $"{url_api_base_ReceiptTaxInvoice}/{url_api_receipttaxinvoice}";
                                var response = new System.Net.Http.HttpResponseMessage();
                                try
                                {
                                    response = await HttpRequestFactory.Post(requestUrl, file_ftp.TokenKey, docs.Documents);
                                    if (response.StatusCode != HttpStatusCode.OK)
                                    {
                                        await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, response.ContentAsString(), false, storeprocedure.sp_receipttaxinvoice, conn);
                                        file_ftp.ErrorContent = response.ContentAsString();
                                        file_ftp.ErrorCount += 1;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    api_connection_error++;
                                    await ExcuteData(file_ftp.FileName, docs.DataContent, ex.Message.ToString(), true, storeprocedure.sp_receipttaxinvoice, conn);
                                }
                            }
                        }
                    }
                }

                conn.Close();
                conn.Dispose();
            }

            if (api_connection_error <= 0)
            {
                if (file_ftp.ErrorCount <= 0) await MoveFileBackup(file_ftp);
                else await MoveFileTransferError(file_ftp);
                return true;
            }
            return false;
        }

        public async Task<bool> SendDocument_AbbTaxInvoice_Async(FileData file_ftp)
        {
            int api_connection_error = 0;

            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                if (file_ftp.List_AbbTaxInvoice != null && file_ftp.List_AbbTaxInvoice.Count > 0)
                {
                    foreach (var docs in file_ftp.List_AbbTaxInvoice)
                    {
                        if (!string.IsNullOrEmpty(docs.Documents.DocumentNumber))
                        {
                            if (!string.IsNullOrEmpty(docs.ErrorContent))
                                // Save Error Log
                                await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, docs.ErrorContent, false, storeprocedure.sp_abbtaxinvoice, conn);
                            else
                            {
                                // Post log data
                                string requestUrl = $"{url_api_base_AbbTaxInvoice}/{url_api_abbtaxinvoice}";
                                var response = new System.Net.Http.HttpResponseMessage();
                                try
                                {
                                    response = await HttpRequestFactory.Post(requestUrl, file_ftp.TokenKey, docs.Documents);
                                    if (response.StatusCode != HttpStatusCode.OK)
                                    {
                                        await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, response.ContentAsString(), false, storeprocedure.sp_abbtaxinvoice, conn);
                                        file_ftp.ErrorContent = response.ContentAsString();
                                        file_ftp.ErrorCount += 1;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    api_connection_error++;
                                    await ExcuteData(file_ftp.FileName, docs.DataContent, ex.Message.ToString(), true, storeprocedure.sp_abbtaxinvoice, conn);
                                }
                            }
                        }
                    }
                }

                conn.Close();
                conn.Dispose();
            }

            if (api_connection_error <= 0)
            {
                if (file_ftp.ErrorCount <= 0) await MoveFileBackup(file_ftp);
                else await MoveFileTransferError(file_ftp);
                return true;
            }
            return false;
        }

        public async Task<bool> SendDocument_CreditNote_Async(FileData file_ftp)
        {
            int api_connection_error = 0;

            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                if (file_ftp.List_CreditNote != null && file_ftp.List_CreditNote.Count > 0)
                {
                    foreach (var docs in file_ftp.List_CreditNote)
                    {
                        if (!string.IsNullOrEmpty(docs.Documents.DocumentNumber))
                        {
                            if (!string.IsNullOrEmpty(docs.ErrorContent))
                                // Save Error Log
                                await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, docs.ErrorContent, false, storeprocedure.sp_creditnote, conn);
                            else
                            {
                                // Post log data
                                string requestUrl = $"{url_api_base_CreditNote}/{url_api_creditnote}";
                                var response = new System.Net.Http.HttpResponseMessage();
                                try
                                {
                                    response = await HttpRequestFactory.Post(requestUrl, file_ftp.TokenKey, docs.Documents);
                                    if (response.StatusCode != HttpStatusCode.OK)
                                    {
                                        await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, response.ContentAsString(), false, storeprocedure.sp_creditnote, conn);
                                        file_ftp.ErrorContent = response.ContentAsString();
                                        file_ftp.ErrorCount += 1;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    api_connection_error++;
                                    await ExcuteData(file_ftp.FileName, docs.DataContent, ex.Message.ToString(), true, storeprocedure.sp_creditnote, conn);
                                }
                            }
                        }
                    }
                }

                conn.Close();
                conn.Dispose();
            }

            if (api_connection_error <= 0)
            {
                if (file_ftp.ErrorCount <= 0) await MoveFileBackup(file_ftp);
                else await MoveFileTransferError(file_ftp);
                return true;
            }
            return false;

        }

        public async Task<bool> SendDocument_DebitNote_Async(FileData file_ftp)
        {
            int api_connection_error = 0;

            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                if (file_ftp.List_DebitNote != null && file_ftp.List_DebitNote.Count > 0)
                {
                    foreach (var docs in file_ftp.List_DebitNote)
                    {
                        if (!string.IsNullOrEmpty(docs.Documents.DocumentNumber))
                        {
                            if (!string.IsNullOrEmpty(docs.ErrorContent))
                                // Save Error Log
                                await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, docs.ErrorContent, false, storeprocedure.sp_debitnote, conn);
                            else
                            {
                                // Post log data
                                string requestUrl = $"{url_api_base_DebitNote}/{url_api_debitnote}";
                                var response = new System.Net.Http.HttpResponseMessage();
                                try
                                {
                                    response = await HttpRequestFactory.Post(requestUrl, file_ftp.TokenKey, docs.Documents);
                                    if (response.StatusCode != HttpStatusCode.OK)
                                    {
                                        await ExcuteData(file_ftp.FileName + GetExtentionError(Enumeration.ErrorType.ErrorTransfer), docs.DataContent, response.ContentAsString(), false, storeprocedure.sp_debitnote, conn);
                                        file_ftp.ErrorContent = response.ContentAsString();
                                        file_ftp.ErrorCount += 1;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    api_connection_error++;
                                    await ExcuteData(file_ftp.FileName, docs.DataContent, ex.Message.ToString(), true, storeprocedure.sp_debitnote, conn);
                                }
                            }
                        }
                    }
                }

                conn.Close();
                conn.Dispose();
            }

            if (api_connection_error <= 0)
            {
                if (file_ftp.ErrorCount <= 0) await MoveFileBackup(file_ftp);
                else await MoveFileTransferError(file_ftp);
                return true;
            }
            return false;
        }

        #endregion

        #region Save Error Document
        public async Task<bool> SaveErrorLogFile_ReceiptTaxInvoice_Async(Enumeration.ErrorType error_type, FileData file_ftp)
        {
            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                await ExcuteData(file_ftp.FileName + GetExtentionError(error_type), file_ftp.DataContent, file_ftp.ErrorContent, false, storeprocedure.sp_receipttaxinvoice, conn);

                conn.Close();

                conn.Dispose();
            }

            switch (error_type)
            {
                case Enumeration.ErrorType.ErrorToken:
                    await MoveFileTokenError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorFormat:
                    await MoveFileFormatError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorTemplate:
                    await MoveFileTemplateError(file_ftp);
                    break;
                default:
                    Console.WriteLine("switch case");
                    break;
            }

            return true;
        }

        public async Task<bool> SaveErrorLogFile_AbbTaxInvoice_Async(Enumeration.ErrorType error_type, FileData file_ftp)
        {
            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                await ExcuteData(file_ftp.FileName + GetExtentionError(error_type), file_ftp.DataContent, file_ftp.ErrorContent, false, storeprocedure.sp_abbtaxinvoice, conn);

                conn.Close();

                conn.Dispose();
            }

            switch (error_type)
            {
                case Enumeration.ErrorType.ErrorToken:
                    await MoveFileTokenError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorFormat:
                    await MoveFileFormatError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorTemplate:
                    await MoveFileTemplateError(file_ftp);
                    break;
                default:
                    Console.WriteLine("switch case");
                    break;
            }

            return true;
        }

        public async Task<bool> SaveErrorLogFile_CreditNote_Async(Enumeration.ErrorType error_type, FileData file_ftp)
        {
            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                await ExcuteData(file_ftp.FileName + GetExtentionError(error_type), file_ftp.DataContent, file_ftp.ErrorContent, false, storeprocedure.sp_creditnote, conn);

                conn.Close();

                conn.Dispose();
            }

            switch (error_type)
            {
                case Enumeration.ErrorType.ErrorToken:
                    await MoveFileTokenError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorFormat:
                    await MoveFileFormatError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorTemplate:
                    await MoveFileTemplateError(file_ftp);
                    break;
                default:
                    Console.WriteLine("switch case");
                    break;
            }

            return true;
        }

        public async Task<bool> SaveErrorLogFile_DebitNote_Async(Enumeration.ErrorType error_type, FileData file_ftp)
        {

            using (SqlConnection conn = new SqlConnection(_SqlDatabase))
            {
                await conn.OpenAsync();

                await ExcuteData(file_ftp.FileName + GetExtentionError(error_type), file_ftp.DataContent, file_ftp.ErrorContent, false, storeprocedure.sp_debitnote, conn);

                conn.Close();

                conn.Dispose();
            }

            switch (error_type)
            {
                case Enumeration.ErrorType.ErrorToken:
                    await MoveFileTokenError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorFormat:
                    await MoveFileFormatError(file_ftp);
                    break;
                case Enumeration.ErrorType.ErrorTemplate:
                    await MoveFileTemplateError(file_ftp);
                    break;
                default:
                    Console.WriteLine("switch case");
                    break;
            }

            return true;
        }

        #endregion

        private string GetExtentionError(Enumeration.ErrorType error_type)
        {
            string xxx = allowfile.allow_transfer_err;
            switch (error_type)
            {
                case Enumeration.ErrorType.ErrorToken:
                    return allowfile.allow_token_err;
                    break;
                case Enumeration.ErrorType.ErrorFormat:
                    return allowfile.allow_format_err;
                    break;
                case Enumeration.ErrorType.ErrorTemplate:
                    return allowfile.allow_template_err;
                    break;
                case Enumeration.ErrorType.ErrorTransfer:
                    return allowfile.allow_transfer_err;
                    break;
                default:
                    return string.Empty;
                    break;
            }
        }

        private async Task<bool> MoveFileTokenError(FileData file_ftp)
        {
            string destFileError = System.IO.Path.Combine(_ErrorDirectory, file_ftp.FileName + allowfile.allow_token_err);

            System.IO.File.Move(file_ftp.SourceFile, destFileError);

            return true;
        }

        private async Task<bool> MoveFileTransferError(FileData file_ftp)
        {
            string destFileError = System.IO.Path.Combine(_ErrorDirectory, file_ftp.FileName + allowfile.allow_transfer_err);

            System.IO.File.Move(file_ftp.SourceFile, destFileError);

            return true;
        }

        private async Task<bool> MoveFileTemplateError(FileData file_ftp)
        {
            string destFileError = System.IO.Path.Combine(_ErrorDirectory, file_ftp.FileName + allowfile.allow_template_err);

            System.IO.File.Move(file_ftp.SourceFile, destFileError);

            return true;
        }

        private async Task<bool> MoveFileFormatError(FileData file_ftp)
        {
            string destFileError = System.IO.Path.Combine(_ErrorDirectory, file_ftp.FileName + allowfile.allow_format_err);

            System.IO.File.Move(file_ftp.SourceFile, destFileError);

            return true;
        }

        private async Task<bool> MoveFileBackup(FileData file_ftp)
        {
            string destFileBackup = System.IO.Path.Combine(_BackupDirectory, file_ftp.FileName + allowfile.allow_backup);

            System.IO.File.Move(file_ftp.SourceFile, destFileBackup);

            return true;
        }

        public static async Task<int> ExcuteData(string file_name, string data_content, string error_content, bool system_error, string store_procedure_name, SqlConnection conn)
        {
            int result = 0;

            using (SqlCommand cmd = new SqlCommand(store_procedure_name, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = ParseDataHelper.DateNowTimeZone();
                cmd.Parameters.Add("@FileName", SqlDbType.VarChar, 200).Value = file_name;
                cmd.Parameters.Add("@DataContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(data_content);
                cmd.Parameters.Add("@ErrorContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(error_content);
                cmd.Parameters.Add("@ErrorType", SqlDbType.VarChar).Value = (system_error == true) ? "System" : "Data";

                SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                rStatus.Direction = ParameterDirection.Output;
                SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                rMessage.Direction = ParameterDirection.Output;

                await cmd.ExecuteNonQueryAsync();

                result = Convert.ToInt32(cmd.Parameters["@rStatus"].Value);
            }

            return result;
        }
    }
}
