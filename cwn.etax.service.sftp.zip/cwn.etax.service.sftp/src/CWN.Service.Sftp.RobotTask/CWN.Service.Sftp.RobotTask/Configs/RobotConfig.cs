﻿namespace CWN.Service.Sms.RobotTask.Configs
{
    public interface IRobotConfig
    {
        string RobotId { get; set; }
        string SftpDirectory { get; set; }
        string ProcessDirectory { get; set; }
        string BackupDirectory { get; set; }
        string ErrorDirectory { get; set; }
        string SqlDatabase { get; set; }
        int SyncFile { get; set; }
        int ProcessFile { get; set; }
        int ProcessFileDelay { get; set; }
        string ExtentionFileBackup { get; set; }
        string ExtentionFileTransferError { get; set; }
        string ExtentionFileFormatError { get; set; }
    }

    public class RobotConfig : IRobotConfig
    {
        public string RobotId { get; set; }
        public string SftpDirectory { get; set; }
        public string ProcessDirectory { get; set; }
        public string BackupDirectory { get; set; }
        public string ErrorDirectory { get; set; }
        public string SqlDatabase { get; set; }
        public int SyncFile { get; set; }
        public int ProcessFile { get; set; }
        public int ProcessFileDelay { get; set; }
        public string ExtentionFileBackup { get; set; }
        public string ExtentionFileTransferError { get; set; }
        public string ExtentionFileFormatError { get; set; }
    }
}
