﻿namespace CWN.Service.Sms.RobotTask.Configs
{
    public interface IApiReceiveConfig
    {
        string BaseUrlReceiptTaxInvoice { get; set; }
        string BaseUrlAbbTaxInvoice { get; set; }
        string BaseUrlCreditNote { get; set; }
        string BaseUrlDebitNote { get; set; }
        string UrlReceiptTaxInvoice { get; set; }
        string UrlAbbTaxInvoice { get; set; }
        string UrlCreditNote { get; set; }
        string UrlDebitNote { get; set; }
    }

    public class ApiReceiveConfig : IApiReceiveConfig
    {
        public string BaseUrlReceiptTaxInvoice { get; set; }
        public string BaseUrlAbbTaxInvoice { get; set; }
        public string BaseUrlCreditNote { get; set; }
        public string BaseUrlDebitNote { get; set; }
        public string UrlReceiptTaxInvoice { get; set; }
        public string UrlAbbTaxInvoice { get; set; }
        public string UrlCreditNote { get; set; }
        public string UrlDebitNote { get; set; }
    }
}
