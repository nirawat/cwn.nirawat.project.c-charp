﻿using CWN.Service.Sftp.RobotTask.Business;
using CWN.Service.Sftp.RobotTask.Business.Jwt;
using CWN.Service.Sftp.RobotTask.Model;
using CWN.Service.Sftp.RobotTask.Model.FileReceive;
using CWN.Service.Sftp.RobotTask.Model.FileReceive.DebitNote.Resource;
using CWN.Service.Sftp.RobotTask.Models.Respones;
using CWN.Service.SFTP.RobotTask.ProcessServices;
using CWN.Service.Sms.Helpers;
using CWN.Service.Sms.RobotTask.Configs;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CWN.Service.SFTP.RobotTask.SyncServices
{
    internal class RobotProcessDebitNote : IHostedService, IDisposable
    {
        #region SFTP CONFIG
        private static AllowExtentionFiles allowfile = new AllowExtentionFiles();
        private static AllowProcess allowprocess = new AllowProcess();
        private static FileContent_DebitNote_Resource sftp_debit_note;
        private static DocDebitNoteResource doc_debit_note;
        private static string _ProcessDirectory;
        private readonly IHandleData _handleData;
        private IRobotConfig _robotconfig;
        private readonly ILogger _logger;
        private Timer _timer;
        #endregion

        public RobotProcessDebitNote(
                                ILogger<RobotProcessDebitNote> logger,
                                IBackgroundTaskQueueProcess queue,
                                IRobotConfig robotconfig,
                                IHandleData handleData)
        {
            Queue = queue;
            _logger = logger;
            _robotconfig = robotconfig;
            _handleData = handleData;

            _ProcessDirectory = Path.Combine(_robotconfig.SftpDirectory, _robotconfig.ProcessDirectory, _robotconfig.RobotId);

        }

        public IBackgroundTaskQueueProcess Queue { get; }
        public static void NewDebitNote()
        {
            sftp_debit_note = new FileContent_DebitNote_Resource();
            doc_debit_note = new DocDebitNoteResource();

            doc_debit_note.Buyer = new DocDebitNoteBuyerResource();
            doc_debit_note.MailingAddress = new DocDebitNoteMailingAddressResource();
            doc_debit_note.PayeeSignature = new DocDebitNotePayeeSignatureResource();
            doc_debit_note.PayerSignature = new DocDebitNotePayerSignatureResource();
            doc_debit_note.ItemDetail = new List<DocDebitNoteDetailResource>();
            doc_debit_note.ItemSendChannel = new List<DocDebitNoteSendInformationResource>();
            doc_debit_note.ItemMessage = new List<DocDebitNoteMessageResource>();
            doc_debit_note.InCorrectAmount = new DocDebitNoteRefundResource();
            doc_debit_note.CorrectAmount = new DocDebitNoteRefundResource();
            doc_debit_note.DifferentAmount = new DocDebitNoteRefundResource();
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Robot Service is starting.");

            _timer = new Timer(DoWork, null, TimeSpan.Zero, TimeSpan.FromSeconds(_robotconfig.ProcessFile));

            return Task.CompletedTask;
        }

        private void DoWork(object state)
        {
            Queue.QueueBackgroundWorkItem(async token =>
            {
                if (System.IO.Directory.Exists(_ProcessDirectory))
                {
                    var dir = new DirectoryInfo(_ProcessDirectory);
                    var list_files = dir
                        .GetFiles()
                        .Where(file => allowprocess.AllowDebitNote.Any(file.Name.ToUpper().StartsWith) && allowfile.allow_process.Any(file.Name.ToLower().EndsWith))
                        .ToList();

                    foreach (var files in list_files)
                    {
                        string content_file = await File.ReadAllTextAsync(files.FullName, token);

                        FileData file_ftp = new FileData();

                        file_ftp.List_DebitNote = new List<FileContent_DebitNote_Resource>();
                        file_ftp.FileName = files.Name;
                        file_ftp.FileNameWithoutExtension = Path.GetFileNameWithoutExtension(file_ftp.FileName);
                        file_ftp.SourceFile = Path.Combine(_ProcessDirectory, file_ftp.FileName);

                        try
                        {
                            string RowHeader = string.Empty;
                            string ContentLine = string.Empty;
                            int LineIndex = 0;
                            int DocNumber = 0;

                            if (!content_file.Contains("�") && !content_file.Contains("?"))
                            {
                                FileStream fs = new FileStream(files.FullName, FileMode.Open, FileAccess.Read);

                                using (StreamReader reader = new StreamReader(fs, Encoding.UTF8))
                                {
                                    while ((ContentLine = await reader.ReadLineAsync()) != null)
                                    {
                                        if (!string.IsNullOrEmpty(ContentLine))
                                        {
                                            if (LineIndex == 0)
                                            {
                                                file_ftp.TokenKey = ContentLine;

                                                //Verify token of folder name
                                                try
                                                {
                                                    DataTokenRespones _token = JwtSecurity.ExtractToken(file_ftp.TokenKey);
                                                    if (_token.BatchKey != null && ($"{_token.BatchKey.CorporateID}-{_token.BatchKey.CompanyID}" != _robotconfig.RobotId))
                                                        goto ExitProcessFileToken;
                                                }
                                                catch (Exception ex)
                                                {
                                                    goto ExitProcessFileToken;
                                                }
                                            }
                                            else
                                            {
                                                RowHeader = ContentLine.Substring(0, 3);

                                                // Header Document
                                                if (RowHeader == "FH|")
                                                {
                                                    string[] FH_LINE = ContentLine.Split("|");

                                                    if (DocNumber >= 1) AddDebitNoteToList(ref file_ftp);

                                                    NewDebitNote();

                                                    Mapping_FH_DebitNote(ContentLine, ref doc_debit_note, ref sftp_debit_note);

                                                    DocNumber++;

                                                }

                                                // Detail Document
                                                if (RowHeader == "RH|")
                                                    Mapping_RH_DebitNote(ContentLine, ref doc_debit_note, ref sftp_debit_note);
                                                if (RowHeader == "TD|")
                                                    Mapping_TD_DebitNote(ContentLine, ref doc_debit_note, ref sftp_debit_note);
                                                if (RowHeader == "DD|")
                                                    Mapping_DD_DebitNote(ContentLine, ref doc_debit_note, ref sftp_debit_note);
                                                if (RowHeader == "BD|")
                                                    Mapping_BD_DebitNote(ContentLine, ref doc_debit_note, ref sftp_debit_note);
                                            }
                                            LineIndex++;
                                        }
                                    }
                                }
                                //Add last document data to file.
                                AddDebitNoteToList(ref file_ftp);

                                // Send Data To Api Receive
                                if (file_ftp.List_DebitNote != null && file_ftp.List_DebitNote.Count > 0) goto SendDocToApi;


                            }
                            else goto ExitProcessFileEncoding;

                        }
                        catch (Exception ex)
                        {
                            file_ftp.DataContent = ("Error: " + content_file);
                            file_ftp.ErrorContent = ex.Message.ToString();
                            await _handleData.SaveErrorLogFile_DebitNote_Async(Enumeration.ErrorType.ErrorTemplate, file_ftp);
                        }

                        // Exit Process File Because Token Error.
                        ExitProcessFileToken:
                        file_ftp.DataContent = ("Error: " + content_file);
                        file_ftp.ErrorContent = "Token incorrect.";
                        await _handleData.SaveErrorLogFile_DebitNote_Async(Enumeration.ErrorType.ErrorToken, file_ftp);
                        break;


                        // Exit Process File Because ncoding Error.
                        ExitProcessFileEncoding:
                        file_ftp.DataContent = ("Error: " + content_file);
                        file_ftp.ErrorContent = "Encoding file incorrect.";
                        await _handleData.SaveErrorLogFile_DebitNote_Async(Enumeration.ErrorType.ErrorFormat, file_ftp);
                        break;

                        // Send Data To Api Receive
                        SendDocToApi:
                        await _handleData.SendDocument_DebitNote_Async(file_ftp);
                        break;

                    }
                }
            });
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {

            _logger.LogTrace("Robot Service is stopping.");

            _timer?.Change(Timeout.Infinite, 0);

            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }

        #region Mapping DebitNote

        private static void AddDebitNoteToList(ref FileData file_ftp)
        {
            if (sftp_debit_note != null && doc_debit_note != null)
            {
                if (doc_debit_note.ItemDetail != null && doc_debit_note.ItemDetail.Count > 0)
                {
                    int row_td = 1;
                    foreach (var item in doc_debit_note.ItemDetail)
                    {
                        item.Seq = row_td;
                        row_td++;
                    }
                }
                if (doc_debit_note.ItemSendChannel != null && doc_debit_note.ItemSendChannel.Count > 0)
                {
                    int row_dd = 1;
                    foreach (var item in doc_debit_note.ItemSendChannel)
                    {
                        item.Seq = row_dd;
                        row_dd++;
                    }
                }
                if (doc_debit_note.ItemMessage != null && doc_debit_note.ItemMessage.Count > 0)
                {
                    int row_bd = 1;
                    foreach (var item in doc_debit_note.ItemMessage)
                    {
                        item.Seq = row_bd;
                        row_bd++;
                    }
                }

                sftp_debit_note.Documents = doc_debit_note;
                file_ftp.List_DebitNote.Add(sftp_debit_note);
            }
        }

        private static void Mapping_FH_DebitNote(
            string content_line,
            ref DocDebitNoteResource doc,
            ref FileContent_DebitNote_Resource doc_file)
        {
            doc_file.DataContent += content_line;
            string[] COLUMN_CONTENT = content_line.Split("|");
            try
            {
                doc.DocumentLanguage = COLUMN_CONTENT[1];
            }
            catch (Exception ex)
            {
                doc_file.ErrorContent += "Error: " + ex.Message.ToString() + System.Environment.NewLine;
            }

        }

        private static void Mapping_RH_DebitNote(
            string content_line,
            ref DocDebitNoteResource doc,
            ref FileContent_DebitNote_Resource doc_file)
        {
            doc_file.DataContent += content_line;
            string[] COLUMN_CONTENT = content_line.Split("|");

            try
            {

                // Buyer
                doc.Buyer.Name = COLUMN_CONTENT[1];
                doc.Buyer.TaxId = COLUMN_CONTENT[2];
                doc.Buyer.BranchName = COLUMN_CONTENT[3];
                doc.Buyer.BuildingNumber = COLUMN_CONTENT[4];
                doc.Buyer.BuildingName = COLUMN_CONTENT[5];
                doc.Buyer.Moo = COLUMN_CONTENT[6];
                doc.Buyer.RoomNo = COLUMN_CONTENT[7];
                doc.Buyer.Floor = COLUMN_CONTENT[8];
                doc.Buyer.Soi = COLUMN_CONTENT[9];
                doc.Buyer.SubSoi = COLUMN_CONTENT[10];
                doc.Buyer.StreetName = COLUMN_CONTENT[11];
                doc.Buyer.Tumbol = COLUMN_CONTENT[12];
                doc.Buyer.Amphur = COLUMN_CONTENT[13];
                doc.Buyer.Province = COLUMN_CONTENT[14];
                doc.Buyer.PostCode = COLUMN_CONTENT[15];
                doc.Buyer.BuyerType = COLUMN_CONTENT[16];
                doc.Buyer.IndividualType = COLUMN_CONTENT[17];
                doc.Buyer.IdentificationType = COLUMN_CONTENT[18];
                doc.Buyer.IdentificationNo = COLUMN_CONTENT[19];
                doc.Buyer.CountryID = COLUMN_CONTENT[20];


                // AdditionalReferencedDocument
                doc.OriginalDocumentDate = ParseDataHelper.ConvertStringToDate(COLUMN_CONTENT[21]);
                doc.OriginalDocumentNumber = COLUMN_CONTENT[22];
                doc.AdditionalReferencedDocument = COLUMN_CONTENT[23];
                doc.ReasonCode = COLUMN_CONTENT[24];
                doc.ReasonDesc = COLUMN_CONTENT[25];

                // InCorrect
                doc.InCorrectAmount.TotalAmount = Convert.ToDecimal(COLUMN_CONTENT[26]);
                doc.InCorrectAmount.DiscountAmount = Convert.ToDecimal(COLUMN_CONTENT[27]);
                doc.InCorrectAmount.VatRate = Convert.ToDecimal(COLUMN_CONTENT[28]);
                doc.InCorrectAmount.VatAmount = Convert.ToDecimal(COLUMN_CONTENT[29]);
                doc.InCorrectAmount.NetAmount = Convert.ToDecimal(COLUMN_CONTENT[30]);

                // Document
                doc.DocumentDate = ParseDataHelper.ConvertStringToDate(COLUMN_CONTENT[31]);
                doc.DocumentNumber = COLUMN_CONTENT[32];
                doc.ActivityDate = ParseDataHelper.ConvertStringToDate(COLUMN_CONTENT[33]);
                doc.PaymentChannel = COLUMN_CONTENT[34];
                doc.PaymentAccountNo = COLUMN_CONTENT[35];
                doc.PaymentOtherChannel​ = COLUMN_CONTENT[36];

                // Correct
                doc.CorrectAmount.TotalAmount = Convert.ToDecimal(COLUMN_CONTENT[37]);
                doc.CorrectAmount.DiscountAmount = Convert.ToDecimal(COLUMN_CONTENT[38]);
                doc.CorrectAmount.VatRate = Convert.ToDecimal(COLUMN_CONTENT[39]);
                doc.CorrectAmount.VatAmount = Convert.ToDecimal(COLUMN_CONTENT[40]);
                doc.CorrectAmount.NetAmount = Convert.ToDecimal(COLUMN_CONTENT[41]);

                // Diff
                doc.DifferentAmount.TotalAmount = Convert.ToDecimal(COLUMN_CONTENT[42]);
                doc.DifferentAmount.DiscountAmount = Convert.ToDecimal(COLUMN_CONTENT[43]);
                doc.DifferentAmount.VatRate = Convert.ToDecimal(COLUMN_CONTENT[44]);
                doc.DifferentAmount.VatAmount = Convert.ToDecimal(COLUMN_CONTENT[45]);
                doc.DifferentAmount.NetAmount = Convert.ToDecimal(COLUMN_CONTENT[46]);

                doc.IsSealer = ParseDataHelper.ConvertStringToBoolean(COLUMN_CONTENT[47]);
                doc.IsRealtime = ParseDataHelper.ConvertStringToBoolean(COLUMN_CONTENT[48]);
                doc.IsSendToCust = ParseDataHelper.ConvertStringToBoolean(COLUMN_CONTENT[49]);
                doc.Password = COLUMN_CONTENT[50];


                //Payee Signature
                doc.PayerSignature.PayerSignatureCode = COLUMN_CONTENT[51];
                doc.PayerSignature.PayerSignatureDate​ = ParseDataHelper.ConvertStringToDate(COLUMN_CONTENT[52]);
                doc.PayeeSignature.PayeeSignatureCode = COLUMN_CONTENT[53];
                doc.PayeeSignature.PayeeSignatureDate​ = ParseDataHelper.ConvertStringToDate(COLUMN_CONTENT[54]);


                // Mailing Address
                doc.UseDocAddForMailing = (COLUMN_CONTENT[55].ToString().ToUpper() == "Y") ? true : false;
                doc.MailingAddress.Name = COLUMN_CONTENT[56];
                doc.MailingAddress.BuildingNumber = COLUMN_CONTENT[57];
                doc.MailingAddress.BuildingName = COLUMN_CONTENT[58];
                doc.MailingAddress.Moo = COLUMN_CONTENT[59];
                doc.MailingAddress.RoomNo = COLUMN_CONTENT[60];
                doc.MailingAddress.Floor = COLUMN_CONTENT[61];
                doc.MailingAddress.Soi = COLUMN_CONTENT[62];
                doc.MailingAddress.SubSoi = COLUMN_CONTENT[63];
                doc.MailingAddress.StreetName = COLUMN_CONTENT[64];
                doc.MailingAddress.Tumbol = COLUMN_CONTENT[65];
                doc.MailingAddress.Amphur = COLUMN_CONTENT[66];
                doc.MailingAddress.Province = COLUMN_CONTENT[67];
                doc.MailingAddress.PostCode = COLUMN_CONTENT[68];
                doc.MailingAddress.CountryID = COLUMN_CONTENT[69];
            }
            catch (Exception ex)
            {
                doc_file.ErrorContent += "Error: " + ex.Message.ToString() + System.Environment.NewLine;
            }


        }

        private static void Mapping_TD_DebitNote(
            string content_line,
            ref DocDebitNoteResource doc,
            ref FileContent_DebitNote_Resource doc_file)
        {
            doc_file.DataContent += content_line;
            string[] COLUMN_CONTENT = content_line.Split("|");
            try
            {
                doc.ItemDetail.Add(new DocDebitNoteDetailResource
                {
                    Description = COLUMN_CONTENT[1],
                    Qty = Convert.ToDecimal(COLUMN_CONTENT[2]),
                    Unit = COLUMN_CONTENT[3],
                    SalePrice = Convert.ToDecimal(COLUMN_CONTENT[4]),
                    DiscountAmount = Convert.ToDecimal(COLUMN_CONTENT[5]),
                    Amount = Convert.ToDecimal(COLUMN_CONTENT[6])
                });
            }
            catch (Exception ex)
            {
                doc_file.ErrorContent += "Error: " + ex.Message.ToString() + System.Environment.NewLine;
            }
        }

        private static void Mapping_DD_DebitNote(
            string content_line,
            ref DocDebitNoteResource doc,
            ref FileContent_DebitNote_Resource doc_file)
        {
            doc_file.DataContent += content_line;
            string[] COLUMN_CONTENT = content_line.Split("|");
            try
            {
                string value_content = COLUMN_CONTENT[2];

                if (!string.IsNullOrEmpty(value_content))
                {
                    string[] DATA_CONTENT = value_content.Split(",");
                    int row = 1;
                    foreach (string line_content in DATA_CONTENT)
                    {
                        if (!string.IsNullOrEmpty(line_content))
                        {
                            doc.ItemSendChannel.Add(new DocDebitNoteSendInformationResource
                            {
                                Seq = row,
                                SendType = COLUMN_CONTENT[1],
                                SendTo = line_content
                            }); ;
                            row++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                doc_file.ErrorContent += "Error: " + ex.Message.ToString() + System.Environment.NewLine;
            }

        }

        private static void Mapping_BD_DebitNote(
            string content_line,
            ref DocDebitNoteResource doc,
            ref FileContent_DebitNote_Resource doc_file)
        {
            doc_file.DataContent += content_line;
            string[] COLUMN_CONTENT = content_line.Split("|");
            try
            {
                doc.ItemMessage.Add(new DocDebitNoteMessageResource
                {
                    Message = COLUMN_CONTENT[1]
                });
            }
            catch (Exception ex)
            {
                doc_file.ErrorContent += "Error: " + ex.Message.ToString() + System.Environment.NewLine;
            }
        }

        #endregion

    }
}
