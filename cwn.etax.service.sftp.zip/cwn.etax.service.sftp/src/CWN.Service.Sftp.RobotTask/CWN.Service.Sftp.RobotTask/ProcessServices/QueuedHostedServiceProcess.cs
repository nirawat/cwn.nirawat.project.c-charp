using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace CWN.Service.SFTP.RobotTask.ProcessServices
{
    #region snippet1
    public class QueuedHostedServiceProcess : BackgroundService
    {
        private readonly ILogger _logger;

        public QueuedHostedServiceProcess(IBackgroundTaskQueueProcess taskQueue,
            ILoggerFactory loggerFactory)
        {
            TaskQueue = taskQueue;
            _logger = loggerFactory.CreateLogger<QueuedHostedServiceProcess>();
        }

        public IBackgroundTaskQueueProcess TaskQueue { get; }

        protected async override Task ExecuteAsync(
            CancellationToken cancellationToken)
        {
            _logger.LogInformation("Queued Hosted Service is starting.");

            while (!cancellationToken.IsCancellationRequested)
            {
                var workItem = await TaskQueue.DequeueAsync(cancellationToken);

                try
                {
                    await workItem(cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex,
                       $"Error occurred executing {nameof(workItem)}.");
                }
            }

            _logger.LogTrace("Queued Hosted Service is stopping.");
        }
    }
    #endregion
}
