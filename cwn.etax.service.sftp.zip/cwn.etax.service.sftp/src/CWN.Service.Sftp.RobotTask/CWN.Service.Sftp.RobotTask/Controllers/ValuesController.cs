﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CWN.Service.Sftp.RobotTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "SFTP Robot Task", "Service Version 1.0" };
        }

    }
}
