﻿using System;

namespace CWN.Service.Sms.Helpers
{
    public class ParseDataHelper
    {
        public static DateTime DateNowTimeZone()
        {
            //return DateTime.Now;

            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Asia/Bangkok");
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZoneInfo);

        }

        public static int ParseInt(string value)
        {
            return int.TryParse(value, out int x) ? int.Parse(value) : 0;
        }

        public static Decimal ParseDecimal(string value)
        {
            return Decimal.TryParse(value, out Decimal x) ? Decimal.Parse(value) : 0;
        }

        public static DateTime? ParseDateTime(string value)
        {
            DateTime? dateTime = null;
            if (DateTime.TryParse(value, out DateTime x))
            {
                dateTime = DateTime.Parse(value);
            }
            return dateTime;
        }

        public static bool Parsebool(string value)
        {
            return Boolean.TryParse(value, out bool x) ? Boolean.Parse(value) : false;
        }

        public static object ConvertDBNull(string _value)
        {
            if (string.IsNullOrEmpty(_value)) return System.DBNull.Value;
            else return _value;
        }
        public static object ConvertDBNullDate(DateTime? _value)
        {
            if (_value == null) return System.DBNull.Value;
            else return _value;
        }
        public static object ConvertDBNullTime(TimeSpan? _value)
        {
            if (_value == null) return System.DBNull.Value;
            else return _value;
        }

        public static bool ParseBool(string value)
        {
            return bool.TryParse(value, out bool x) ? bool.Parse(value) : false;
        }

        public static DateTime ConvertStringToDate(string date_string)
        {
            DateTime dt = Convert.ToDateTime("01/01/1991");

            if (!string.IsNullOrWhiteSpace(date_string))
            {
                string string_date = string.Empty;
                string_date = date_string.Insert(2, "/").Insert(5, "/");
                dt = Convert.ToDateTime(string_date);
            }
            return dt;
        }

        public static bool ConvertStringToBoolean(string bool_string)
        {
            if (!string.IsNullOrWhiteSpace(bool_string)) return (bool_string.ToUpper() == "Y") ? true : false;
            return false;
        }

    }
}
