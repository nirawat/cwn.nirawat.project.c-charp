﻿using CWN.Service.Sftp.RobotTask.Models.Respones;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace CWN.Service.Sftp.RobotTask.Business.Jwt
{

    public class JwtSecurity
    {
        public static DataTokenRespones ExtractToken(string TokenKey)
        {
            var handler = new JwtSecurityTokenHandler();
            string authHeader = TokenKey;
            DataTokenRespones resp = new DataTokenRespones();
            if (authHeader != null)
            {
                authHeader = authHeader.Replace("Bearer ", "");
                var jsonToken = handler.ReadToken(authHeader);
                var tokenS = handler.ReadToken(authHeader) as JwtSecurityToken;

                string UserData = tokenS.Claims.First(claim => claim.Type == "http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata").Value;
                resp = JsonConvert.DeserializeObject<DataTokenRespones>(UserData);
            }

            return resp;
        }
    }
}
