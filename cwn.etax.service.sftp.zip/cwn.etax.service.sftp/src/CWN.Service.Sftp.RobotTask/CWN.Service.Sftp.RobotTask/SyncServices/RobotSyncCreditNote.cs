﻿using CWN.Service.Sftp.RobotTask.Business;
using CWN.Service.Sftp.RobotTask.Model;
using CWN.Service.Sms.Helpers;
using CWN.Service.Sms.RobotTask.Configs;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CWN.Service.SFTP.RobotTask.SyncServices
{
    internal class RobotSyncCreditNote : IHostedService, IDisposable
    {
        private static AllowExtentionFiles allowfile = new AllowExtentionFiles();
        private static AllowSynchronous allowsync = new AllowSynchronous();
        private static string _SftpDirectory;
        private static string _ProcessDirectory;
        private static string _ErrorDirectory;
        private IRobotConfig _robotconfig;
        private readonly IHandleData _handleData;
        private readonly ILogger _logger;
        private Timer _timer;

        public RobotSyncCreditNote(
                                ILogger<RobotSyncCreditNote> logger,
                                IBackgroundTaskQueueSync queue,
                                IRobotConfig robotconfig,
                                IHandleData handleData)
        {
            Queue = queue;
            _logger = logger;
            _robotconfig = robotconfig;
            _handleData = handleData;

            _SftpDirectory = Path.Combine(_robotconfig.SftpDirectory, _robotconfig.RobotId);
            _ProcessDirectory = Path.Combine(_robotconfig.SftpDirectory, _robotconfig.ProcessDirectory, _robotconfig.RobotId);
            _ErrorDirectory = Path.Combine(_robotconfig.SftpDirectory, _robotconfig.ErrorDirectory, _robotconfig.RobotId);

            _handleData.GetDirectory();
        }

        public IBackgroundTaskQueueSync Queue { get; }

        private static int numberOfConcurrentMoves = 2;

        private static List<Task> moves = new List<Task>();

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Robot Service is starting.");

            _timer = new Timer(DoWork, null, TimeSpan.Zero, TimeSpan.FromSeconds(_robotconfig.SyncFile));

            return Task.CompletedTask;
        }

        private void DoWork(object state)
        {
            Queue.QueueBackgroundWorkItem(async token =>
            {
                try
                {
                    if (System.IO.Directory.Exists(_SftpDirectory))
                    {
                        var dir = new DirectoryInfo(_SftpDirectory);
                        var list_files = dir
                            .GetFiles()
                            .Where(file => allowsync.AllowCreditNote.Any(file.Name.ToUpper().StartsWith) && allowfile.allow_sftp.Any(file.Name.ToLower().EndsWith))
                            .ToList();

                        foreach (var filePath in list_files)
                        {
                            var move = new Task(() =>
                            {
                                string getFilename = filePath.Name;
                                string sourceFile = Path.Combine(_SftpDirectory, getFilename);
                                string destFileBackup = Path.Combine(_ProcessDirectory,
                                    Path.GetFileNameWithoutExtension(getFilename) + ParseDataHelper.DateNowTimeZone().ToString(" yyyyMMddHHmmss") + allowfile.allow_process[0]);
                                System.IO.File.Move(sourceFile, destFileBackup);
                            }, TaskCreationOptions.PreferFairness);
                            move.Start();

                            moves.Add(move);

                            if (moves.Count >= numberOfConcurrentMoves)
                            {
                                Task.WaitAll(moves.ToArray());
                                moves.Clear();
                            }
                        }

                        Task.WaitAll(moves.ToArray());
                    }

                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error: {ex.Message}");
                }
                await Task.Delay(TimeSpan.FromSeconds(0), token);
            });
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {

            _logger.LogTrace("Robot Service is stopping.");

            _timer?.Change(Timeout.Infinite, 0);

            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }

    }
}
