﻿using Microsoft.EntityFrameworkCore;

namespace CWN.Service.Mail.Entities.CWN_ServiceMail
{
    public class Sevice_Mail_Context : DbContext
    {
        public Sevice_Mail_Context(DbContextOptions<Sevice_Mail_Context> options) : base(options)
        {
        }

        public DbSet<MST_Register> MST_Registers { get; set; }
        public DbSet<Mail_Tracking> Mail_Trackings { get; set; }
        public DbSet<Mail_Job> Mail_Jobs { get; set; }

    }
}
