﻿using CWN.Service.Mail.Entities;
using CWN.Service.Mail.Helpers;
using CWN.Service.Mail.Repository.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace CWN.Service.Mail.Repository
{
    public class MST_RegisterRepository : IMST_RegisterRepository
    {
        private readonly IConfiguration _configuration;
        private readonly string ConnectionString;
        private readonly IIntersectsTime _IIntersectsTime;

        public MST_RegisterRepository(IConfiguration configuration, IIntersectsTime IIntersectsTimes)
        {
            _configuration = configuration;
            _IIntersectsTime = IIntersectsTimes;
            ConnectionString = Encoding.UTF8.GetString(Convert.FromBase64String(_configuration.GetConnectionString("dbServiceMail")));
        }

        public async Task<string> RegisterUser(MST_Register model)
        {
            var TokenKey = GenerateToken.GetToken(model.StartTime, model.EndTime);
            string sp_name = "sp_RegisterUser";

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sp_name, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@NewToken", SqlDbType.VarChar, 500).Value = TokenKey;
                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = _IIntersectsTime.DateNowTimeZone();
                    cmd.Parameters.Add("@Username", SqlDbType.VarChar, 200).Value = model.Username;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 500).Value = GeneratePassw.GetPassword(model.Password);
                    cmd.Parameters.Add("@StartTime", SqlDbType.Time, 7).Value = model.StartTime;
                    cmd.Parameters.Add("@EndTime", SqlDbType.Time, 7).Value = model.EndTime;

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;
                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();

                    if ((int)cmd.Parameters["@rStatus"].Value == 0) TokenKey = string.Empty;
                }
                conn.Close();
            }
            return TokenKey;
        }

        public async Task<string> UpdateInformation(MST_Register model)
        {
            var TokenKey = GenerateToken.GetToken(model.StartTime, model.EndTime);
            var OldToken = model.Token;
            try
            {
                string sp_name = "sp_UpdateInformation";

                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sp_name, conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@OldToken", SqlDbType.VarChar, 500).Value = OldToken;
                        cmd.Parameters.Add("@NewToken", SqlDbType.VarChar, 500).Value = TokenKey;
                        cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = _IIntersectsTime.DateNowTimeZone();
                        cmd.Parameters.Add("@Username", SqlDbType.VarChar, 200).Value = model.Username;
                        cmd.Parameters.Add("@Password", SqlDbType.VarChar, 500).Value = GeneratePassw.GetPassword(model.Password);
                        cmd.Parameters.Add("@StartTime", SqlDbType.Time, 7).Value = model.StartTime;
                        cmd.Parameters.Add("@EndTime", SqlDbType.Time, 7).Value = model.EndTime;

                        SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                        rStatus.Direction = ParameterDirection.Output;
                        SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                        rMessage.Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        if ((int)cmd.Parameters["@rStatus"].Value == 0) return string.Empty;
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return TokenKey;
        }

        public async Task<string> GetToken(MST_Register model)
        {
            string TokenKey = string.Empty;
            string Password = GeneratePassw.GetPassword(model.Password);

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand("sp_GetPeriodTimeOfRegister", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@OldToken", SqlDbType.VarChar, 500).Value = model.Token;
                    cmd.Parameters.Add("@Username", SqlDbType.VarChar, 200).Value = model.Username;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 500).Value = Password;

                    SqlDataReader reader = cmd.ExecuteReader();

                    TimeSpan _starttime;
                    TimeSpan _endtime;
                    while (reader.Read())
                    {
                        _starttime = (TimeSpan)reader["StartTime"];
                        _endtime = (TimeSpan)reader["EndTime"];
                    }
                    reader.Close();
                    TokenKey = GenerateToken.GetToken(_starttime, _endtime);
                }

                using (SqlCommand cmd = new SqlCommand("sp_GetToken", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = _IIntersectsTime.DateNowTimeZone();
                    cmd.Parameters.Add("@Username", SqlDbType.VarChar, 200).Value = model.Username;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 500).Value = Password;
                    cmd.Parameters.Add("@NewToken", SqlDbType.VarChar, 500).Value = TokenKey;

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;

                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();

                    if ((int)cmd.Parameters["@rStatus"].Value == 0) TokenKey = string.Empty;
                }

                conn.Close();
            }

            return TokenKey;
        }

        public async Task<bool> ValidateTokenKey(string TokenKey)
        {
            int count = 0;

            string sql = "SELECT COUNT(Token) FROM MST_Register " +
                         "WHERE IsActive='1' AND Token=@Token";

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(sql, conn))
                {
                    command.Parameters.Add("@Token", SqlDbType.NVarChar).Value = TokenKey;
                    count = (int)await command.ExecuteScalarAsync();
                }
                conn.Close();
            }

            return count > 0;
        }

    }
}
