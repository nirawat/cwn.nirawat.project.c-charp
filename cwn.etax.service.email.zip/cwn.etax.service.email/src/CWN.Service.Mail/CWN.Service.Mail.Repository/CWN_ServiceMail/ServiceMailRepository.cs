﻿using CWN.Service.Email.Helpers;
using CWN.Service.Mail.Entities;
using CWN.Service.Mail.Entities.CWN_ServiceMail;
using CWN.Service.Mail.Helpers;
using CWN.Service.Mail.Models.Response;
using CWN.Service.Mail.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWN.Service.Mail.Repository
{
    public class ServiceMailRepository : IServiceMailRepository
    {
        private readonly IConfiguration _configuration;
        private readonly Sevice_Mail_Context _Service_Mail_Contexts;
        private readonly string ConnectionString;
        private readonly IIntersectsTime _IIntersectsTime;
        public ServiceMailRepository(IConfiguration configuration,
            Sevice_Mail_Context Service_Mail_Contexts,
            IIntersectsTime IIntersectsTime)
        {
            _configuration = configuration;
            _Service_Mail_Contexts = Service_Mail_Contexts;
            _IIntersectsTime = IIntersectsTime;
            ConnectionString = Encoding.UTF8.GetString(Convert.FromBase64String(_configuration.GetConnectionString("dbServiceMail")));
        }

        public async Task<int> Mail_Send(Mail_Send model)
        {
            int trackID = 0;

            DateTime dtnow = _IIntersectsTime.DateNowTimeZone();

            string sp_name = "sp_Mail_Send";

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sp_name, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = dtnow;
                    cmd.Parameters.Add("@isSend", SqlDbType.Bit).Value = model.IsSend;
                    cmd.Parameters.Add("@SendDateTime", SqlDbType.DateTime).Value = dtnow;
                    cmd.Parameters.Add("@StartTime", SqlDbType.Time, 7).Value = ParseDataHelper.ConvertDBNullTime(model.StartTime);
                    cmd.Parameters.Add("@EndTime", SqlDbType.Time, 7).Value = ParseDataHelper.ConvertDBNullTime(model.EndTime);
                    cmd.Parameters.Add("@PackageKey", SqlDbType.VarChar, 100).Value = model.PackageKey;
                    cmd.Parameters.Add("@ReferenceKey1", SqlDbType.VarChar, 100).Value = model.ReferenceKey;
                    cmd.Parameters.Add("@ReferenceKey2", SqlDbType.VarChar, 100).Value = model.ReferenceKey2;
                    cmd.Parameters.Add("@ReferenceKey3", SqlDbType.VarChar, 100).Value = model.ReferenceKey3;
                    cmd.Parameters.Add("@FromName", SqlDbType.VarChar, 100).Value = model.FromName;
                    cmd.Parameters.Add("@FromEmail", SqlDbType.VarChar, 200).Value = model.FromEmail;
                    cmd.Parameters.Add("@ToMail", SqlDbType.VarChar, 200).Value = model.ToEmail;
                    cmd.Parameters.Add("@Subject", SqlDbType.VarChar, 100).Value = model.Subject;
                    cmd.Parameters.Add("@Message", SqlDbType.NVarChar).Value = model.Message;
                    cmd.Parameters.Add("@Attachment", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(model.Attachment);
                    cmd.Parameters.Add("@AttachmentName", SqlDbType.VarChar, 100).Value = ParseDataHelper.ConvertDBNull(model.AttachmentName);
                    cmd.Parameters.Add("@TemplateID", SqlDbType.VarChar, 100).Value = ParseDataHelper.ConvertDBNull(model.TemplateID);
                    cmd.Parameters.Add("@TemplateParameter", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull((string)JsonConvert.SerializeObject(model.TemplateParameter));
                    cmd.Parameters.Add("@ResultTrackingID", SqlDbType.VarChar, 100).Value = ParseDataHelper.ConvertDBNull(model.ResultTrackingID);
                    cmd.Parameters.Add("@ResultContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(model.ResultContent);

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;

                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    SqlParameter rTrackID = cmd.Parameters.Add("@rTrackID", SqlDbType.Int);
                    rTrackID.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();

                    trackID = Convert.ToInt32(cmd.Parameters["@rTrackID"].Value);

                }
                conn.Close();
            }
            return trackID;
        }

        public async Task<IList<Mail_Job>> GetAll_Jobs()
        {
            DateTime dtnow = _IIntersectsTime.DateNowTimeZone();

            return await _Service_Mail_Contexts.Mail_Jobs.Where(e => (e.StartTime <= dtnow.TimeOfDay && e.EndTime >= dtnow.TimeOfDay)).ToListAsync();

        }

        public async Task<bool> UpdateTrackingAsync(string TrackingID, NipaTrackingStatusResponse ResultContent)
        {
            bool result = false;

            DateTime dtnow = _IIntersectsTime.DateNowTimeZone();

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                await conn.OpenAsync();

                using (SqlCommand cmd = new SqlCommand("sp_Mail_Tracking", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@TrackingID", SqlDbType.VarChar, 100).Value = TrackingID;
                    cmd.Parameters.Add("@TrackingStatus", SqlDbType.VarChar, 100).Value = ParseDataHelper.ConvertDBNull(ResultContent.data.status);
                    cmd.Parameters.Add("@ResultContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(JsonConvert.SerializeObject(ResultContent));
                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = dtnow;

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;
                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();

                    result = ((int)(cmd.Parameters["@rStatus"].Value) >= 1) ? true : false;

                }
                conn.Close();
                conn.Dispose();
            }

            return result;

        }

    }
}
