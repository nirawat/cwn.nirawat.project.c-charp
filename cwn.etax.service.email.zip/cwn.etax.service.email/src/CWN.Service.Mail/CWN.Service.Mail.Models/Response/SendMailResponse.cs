﻿using System;

namespace CWN.Service.Mail.Models.Response
{
    public class SendMailResponse
    {
        public bool status { get; set; }
        public string trackingID { get; set; }
        public string description { get; set; }
    }
    public class NipaSendMailResponse
    {
        public string id { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public decimal credits { get; set; }
        public DateTime date { get; set; }
        public string status_code { get; set; }
    }


}
