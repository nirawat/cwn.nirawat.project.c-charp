﻿using System;

namespace CWN.Service.Mail.Models.Response
{
    public class TrackingStatusResponse
    {
        public bool Status { get; set; }
        public DateTime SendCompleteDateTime { get; set; }
        public string Description { get; set; }
        public string ErrorType { get; set; }
        public string ErrorRemark { get; set; }
    }

    public class NipaTrackingStatusResponse
    {
        public int status { get; set; }
        public DateTime date { get; set; }
        public NipaTrackingStatusDataResponse data { get; set; }
    }
    public class NipaTrackingStatusDataResponse
    {
        public string tran_id { get; set; }
        public string app_id { get; set; }
        public int open { get; set; }
        public int click { get; set; }
        public int unsubscriber { get; set; }
        public string status { get; set; }
        public string create_date { get; set; }
        public NipaTrackingStatusDataErrorResponse errors { get; set; }
    }

    public class NipaTrackingStatusDataErrorResponse
    {
        public string type { get; set; }
        public string remark { get; set; }
        public string message { get; set; }
    }
}
