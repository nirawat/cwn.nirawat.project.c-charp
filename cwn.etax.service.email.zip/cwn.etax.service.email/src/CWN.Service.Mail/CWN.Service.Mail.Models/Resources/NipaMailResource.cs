﻿namespace CWN.Service.Mail.Models.Resources
{
    public class NipaMailResource
    {
        public string package_key { get; set; }
        public string sendid { get; set; }
        public string jobid { get; set; }
        public string referancekey1 { get; set; }
        public string referancekey2 { get; set; }
        public string referancekey3 { get; set; }
        public string from_name { get; set; }
        public string from_email { get; set; }
        public string to { get; set; }
        public string subject { get; set; }
        public string message { get; set; }
        public string template_id { get; set; }
        public dynamic parameters { get; set; }
        public string attach_type { get; set; }
        public dynamic attachment { get; set; }
    }

}
