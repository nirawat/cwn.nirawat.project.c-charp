﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CWN.Service.Mail.Models.Resources
{
    public class EncryptResource
    {
        public string text { get; set; }
    }
    public class DecryptResource
    {
        public string cipherText { get; set; }
    }
}
