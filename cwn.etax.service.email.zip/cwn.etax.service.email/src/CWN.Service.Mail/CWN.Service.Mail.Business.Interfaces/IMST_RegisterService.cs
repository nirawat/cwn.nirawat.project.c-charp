﻿using CWN.Service.Mail.Entities;
using System.Threading.Tasks;

namespace CWN.Service.Mail.Business.Interfaces
{
    public interface IMST_RegisterService
    {
        Task<string> RegisterUser(MST_Register model);
        Task<string> UpdateInformation(MST_Register model);
        Task<string> GetToken(MST_Register model);
        Task<bool> ValidateTokenKey(string TokenKey);
    }
}
