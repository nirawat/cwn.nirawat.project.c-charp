﻿using CWN.Service.Mail.Entities;
using CWN.Service.Mail.Models.Response;
using System.Threading.Tasks;

namespace CWN.Service.Mail.Business.Interfaces
{
    public interface IServiceMailService
    {
        Task<SendMailResponse> Mail_Send(Mail_Send model, NipaSendMailResponse reslt);
        Task<bool> UpdateTrackingAsync(string TrackingID, NipaTrackingStatusResponse ResultContent);
    }
}
