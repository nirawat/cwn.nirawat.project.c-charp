﻿using CWN.Service.Mail.Business.Interfaces;
using CWN.Service.Mail.Entities;
using CWN.Service.Mail.Helpers;
using CWN.Service.Mail.Models.Resources;
using CWN.Service.Mail.Models.Response;
using CWN.Service.Mail.WebApi.ApiConnector;
using CWN.Service.Mail.WebApi.Configs;
using CWN.Service.Mail.WebApi.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CWN.Service.Mail.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NipaServiceMailController : ControllerBase
    {
        private IHttpContextAccessor _httpContextAccessor;
        private readonly IServiceMailService _IServiceMailService;
        private INipaMailConfig _nipamailconfig;
        private IRobotConfig _robotconfig;
        private readonly IIntersectsTime _IIntersectsTime;
        private string _url_sendmail;
        private string _url_tracking;
        private string _packagekey1mb;
        private string _packagekey2mb;
        private string _attachtype;

        public NipaServiceMailController(
            IHttpContextAccessor httpContextAccessor,
            IServiceMailService IServiceMailService,
            INipaMailConfig nipamailconfig,
            IIntersectsTime IIntersectsTimes,
            IRobotConfig robotconfig)
        {
            _httpContextAccessor = httpContextAccessor;
            _IIntersectsTime = IIntersectsTimes;
            _robotconfig = robotconfig;
            _IServiceMailService = IServiceMailService;

            _nipamailconfig = nipamailconfig;

            _url_sendmail = Encoding.UTF8.GetString(Convert.FromBase64String(_nipamailconfig.SendMailUrl));
            _url_sendmail = $"{string.Format(_url_sendmail, _nipamailconfig.TokenKey)}";
            _url_tracking = Encoding.UTF8.GetString(Convert.FromBase64String(_nipamailconfig.TrackingUrl));
            _packagekey1mb = _nipamailconfig.PackageKey1MB;
            _packagekey2mb = _nipamailconfig.PackageKey2MB;
            _attachtype = Encoding.UTF8.GetString(Convert.FromBase64String(_nipamailconfig.AttachType)); ;
        }


        [HttpPost("Sends")]
        public async Task<IActionResult> Sends([FromBody]Mail_Send model)
        {
            IActionResult _result = BadRequest();
            string token_key = string.Empty;
            _httpContextAccessor.HttpContext.Response.ContentType = new MediaTypeHeaderValue("application/json").ToString();
            string authHeader = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            if (authHeader != null && authHeader.StartsWith("Bearer")) token_key = authHeader.Substring("Bearer ".Length).Trim();

            string APIKEY = Encoding.UTF8.GetString(Convert.FromBase64String(token_key));
            string[] split_apikey = APIKEY.Split('|');
            model.StartTime = TimeSpan.Parse(split_apikey[1]);
            model.EndTime = TimeSpan.Parse(split_apikey[2].Replace("}", ""));


            CancellationTokenSource source = new CancellationTokenSource();

            var tasks = Task.Run(async delegate
            {

                NipaMailResource mail = new NipaMailResource();

                mail.package_key = _packagekey1mb;
                model.PackageKey = _packagekey1mb;
                if (!string.IsNullOrWhiteSpace(model.Attachment))
                {
                    byte[] fileBytes = Convert.FromBase64String(model.Attachment);
                    FileSizeResponse filesize = FileSize.GetFileSize(fileBytes.Length);
                    if (filesize.SizeIndex <= 2 && filesize.SizeName == "MB")
                    {
                        mail.package_key = filesize.SizeCount > Convert.ToDecimal(1.00) ? _packagekey2mb : _packagekey1mb;
                        model.PackageKey = mail.package_key;
                    }
                    mail.attach_type = _attachtype;
                    mail.attachment = JsonConvert.DeserializeObject("{ 'name': '" + model.AttachmentName + "', 'string': '" + model.Attachment + "' }");
                }

                mail.from_name = model.FromName;
                mail.from_email = model.FromEmail;
                mail.to = model.ToEmail;
                mail.subject = model.Subject;
                mail.message = model.Message;
                if (!string.IsNullOrWhiteSpace(model.TemplateID))
                {
                    mail.template_id = model.TemplateID;
                    mail.parameters = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(model.TemplateParameter));
                }


                if (!await _IIntersectsTime.IsValidTimeAsync(model.StartTime.Value, model.EndTime.Value))
                {
                    NipaSendMailResponse result = JsonConvert.DeserializeObject<NipaSendMailResponse>("{}");
                    model.IsSend = false;
                    var resp = await _IServiceMailService.Mail_Send(model, result);
                    if (!resp.status) _result = BadRequest();
                    else _result = Ok(resp);
                }
                else
                {
                    string requestUri = $"{_url_sendmail}";
                    using (var httpResponse = await HttpRequestFactory.Post(requestUri, string.Empty, mail))
                    {
                        if (httpResponse.StatusCode == HttpStatusCode.OK)
                        {
                            NipaSendMailResponse result = JsonConvert.DeserializeObject<NipaSendMailResponse>(httpResponse.ContentAsString());
                            model.IsSend = true;
                            model.SendDateTime = _IIntersectsTime.DateNowTimeZone();
                            var resp = await _IServiceMailService.Mail_Send(model, result);
                            _result = Ok(resp);
                        }
                        else if (httpResponse.StatusCode == HttpStatusCode.Unauthorized) _result = Unauthorized();
                        else if (httpResponse.StatusCode == HttpStatusCode.BadRequest) _result = BadRequest();
                        else if (httpResponse.StatusCode == HttpStatusCode.Forbidden) _result = StatusCode(403);
                        else _result = StatusCode(500);
                    }
                }
                await Task.Delay(TimeSpan.FromSeconds(_robotconfig.SendDelay), source.Token);
                return _result;
            });
            source.Cancel();
            try
            {
                tasks.Wait();
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.InnerExceptions)
                    Console.WriteLine("{0}: {1}", e.GetType().Name, e.Message);
            }
            if (tasks.Status == TaskStatus.RanToCompletion)
                source.Dispose();
            return _result;
        }

        [HttpGet("GetTrackingStatus")]
        public async Task<IActionResult> GetTrackingStatus([FromBody]Mail_Tracking model)
        {
            if (string.IsNullOrWhiteSpace(model.TrackingID)) return BadRequest();

            IActionResult _result = BadRequest();

            CancellationTokenSource source = new CancellationTokenSource();

            var tasks = Task.Run(async delegate
            {
                var requestUri = $"{string.Format(_url_tracking, model.TrackingID, _nipamailconfig.TokenKey)}";

                using (var httpResponse = await HttpRequestFactory.Get(requestUri, string.Empty))
                {
                    switch (httpResponse.StatusCode)
                    {
                        case HttpStatusCode.OK:
                            {
                                NipaTrackingStatusResponse result = JsonConvert.DeserializeObject<NipaTrackingStatusResponse>(httpResponse.ContentAsString());

                                await _IServiceMailService.UpdateTrackingAsync(model.TrackingID, result);

                                _result = Ok(new
                                {
                                    Status = (result.data.status == "delivered" ? true : false),
                                    SendCompleteDateTime = result.data.create_date,
                                    Description = (result.data.status == "delivered" ? "" : "In Progress..."),
                                    ErrorType = (result.data.status == "delivered" ? result.data.status : ""),
                                    ErrorrRemark = (result.data.status == "delivered" ? result.data.status : ""),
                                }); ;
                                break;
                            }

                        case HttpStatusCode.Unauthorized:
                            _result = Unauthorized();
                            break;
                        case HttpStatusCode.BadRequest:
                            _result = BadRequest();
                            break;
                        case HttpStatusCode.Forbidden:
                            _result = StatusCode(403);
                            break;
                        default:
                            _result = StatusCode(500);
                            break;
                    }
                }

                await Task.Delay(TimeSpan.FromSeconds(_robotconfig.TrackingDelay), source.Token);

                return _result;

            });
            source.Cancel();
            try
            {
                tasks.Wait();
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.InnerExceptions)
                    Console.WriteLine("{0}: {1}", e.GetType().Name, e.Message);
            }
            if (tasks.Status == TaskStatus.RanToCompletion)
                source.Dispose();
            return _result;
        }


    }
}