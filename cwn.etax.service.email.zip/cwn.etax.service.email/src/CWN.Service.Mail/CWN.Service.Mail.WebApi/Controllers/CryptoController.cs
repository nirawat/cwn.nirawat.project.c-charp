﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CWN.Service.Mail.Helpers;
using CWN.Service.Mail.Models.Resources;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace CWN.Service.Mail.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CryptoController : ControllerBase
    {
        private RSAHelper rsa;
        private AESHelper aes;
        private readonly IConfiguration configuration;
        private readonly IDataProtectionProvider _dataProtectionProvider;

        public CryptoController(IConfiguration configuration,
            IDataProtectionProvider dataProtectionProvider)
        {
            this.configuration = configuration;
            _dataProtectionProvider = dataProtectionProvider;
            rsa = new RSAHelper(this.configuration);
            aes = new AESHelper(this.configuration, _dataProtectionProvider);
        }


        [HttpPost("RSAEncrypt")]
        public IActionResult Encrypt([FromBody]EncryptResource model)
        {
            return Ok(new { encrypt = rsa.Encrypt(model.text) });
        }
        [HttpPost("RSADecrypt")]
        public IActionResult Decrypt([FromBody]DecryptResource model)
        {
            return Ok(new { decrypt = rsa.Decrypt(model.cipherText) });
        }
        [HttpPost("AESEncrypt")]
        public IActionResult AESEncrypt([FromBody]EncryptResource model)
        {
            return Ok(new { encrypt = aes.Encrypt(model.text) });
        }
        [HttpPost("AESDecrypt")]
        public IActionResult AESDecrypt([FromBody]DecryptResource model)
        {
            return Ok(new { decrypt = aes.Decrypt(model.cipherText) });
        }


    }
}