﻿namespace CWN.Service.Mail.WebApi.Configs
{
    public interface IRobotConfig
    {
        int SendDelay { get; set; }
        int TrackingDelay { get; set; }
    }

    public class RobotConfig : IRobotConfig
    {
        public int SendDelay { get; set; }
        public int TrackingDelay { get; set; }
    }
}
