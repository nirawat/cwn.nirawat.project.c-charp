﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CWN.Service.Mail.WebApi.Model
{
    public interface INipaMailConfig
    {
        string TokenKey { get; set; }
        string PackageKey1MB { get; set; }
        string PackageKey2MB { get; set; }
        string AttachType { get; set; }
        string SendMailUrl { get; set; }
        string TrackingUrl { get; set; }
    }

    public class NipaMailConfig: INipaMailConfig
    {
        public string TokenKey { get; set; }
        public string PackageKey1MB { get; set; }
        public string PackageKey2MB { get; set; }
        public string AttachType { get; set; }
        public string SendMailUrl { get; set; }
        public string TrackingUrl { get; set; }
    }
}
