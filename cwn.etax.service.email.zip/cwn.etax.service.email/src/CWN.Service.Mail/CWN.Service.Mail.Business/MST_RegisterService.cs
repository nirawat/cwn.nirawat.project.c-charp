﻿using CWN.Service.Mail.Business.Interfaces;
using CWN.Service.Mail.Entities;
using CWN.Service.Mail.Repository.Interfaces;
using System.Threading.Tasks;

namespace CWN.Service.Mail.Business
{
    public class MST_RegisterService : IMST_RegisterService
    {
        private readonly IMST_RegisterRepository _MST_RegisterRepository;

        public MST_RegisterService(IMST_RegisterRepository MST_RegisterRepository)
        {
            _MST_RegisterRepository = MST_RegisterRepository;
        }

        public async Task<string> GetToken(MST_Register model)
        {
            return await _MST_RegisterRepository.GetToken(model);
        }

        public async Task<string> RegisterUser(MST_Register model)
        {

            if (model.StartTime.Ticks <= 0) return "StartTime is required.";

            if (model.EndTime.Ticks <= 0) return "EndTime is required.";

            var time_total = (model.EndTime.Subtract(model.StartTime).TotalMinutes);

            if (time_total <= 0) return "Period time invalid.";

            return await _MST_RegisterRepository.RegisterUser(model);
        }
        public async Task<string> UpdateInformation(MST_Register model)
        {

            if (model.StartTime.Ticks <= 0) return "StartTime is required.";

            if (model.EndTime.Ticks <= 0) return "EndTime is required.";

            var time_total = (model.EndTime.Subtract(model.StartTime).TotalMinutes);

            if (time_total <= 0) return "Period time invalid.";

            return await _MST_RegisterRepository.UpdateInformation(model);
        }
        public async Task<bool> ValidateTokenKey(string TokenKey)
        {
            return await _MST_RegisterRepository.ValidateTokenKey(TokenKey);
        }

    }
}
