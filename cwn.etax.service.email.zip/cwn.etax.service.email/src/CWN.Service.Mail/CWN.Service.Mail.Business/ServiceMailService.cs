﻿using CWN.Service.Mail.Business.Interfaces;
using CWN.Service.Mail.Entities;
using CWN.Service.Mail.Helpers;
using CWN.Service.Mail.Models.Response;
using CWN.Service.Mail.Repository.Interfaces;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace CWN.Service.Mail.Business
{
    public class ServiceMailService : IServiceMailService
    {
        private readonly IServiceMailRepository _ServiceMailRepository;
        private readonly IIntersectsTime _IIntersectsTime;

        public ServiceMailService(IServiceMailRepository ServiceMailRepository, IIntersectsTime IIntersectsTimes)
        {
            _ServiceMailRepository = ServiceMailRepository;
            _IIntersectsTime = IIntersectsTimes;
        }

        public async Task<SendMailResponse> Mail_Send(Mail_Send model, NipaSendMailResponse result)
        {
            SendMailResponse resp = new SendMailResponse();

            resp.status = false;
            resp.trackingID = string.Empty;
            resp.description = (result.message == null) ? string.Empty : result.message;

            if (model.IsSend)
            {
                if (result.status_code == "200")//Success
                {
                    model.ResultTrackingID = result.id;
                    model.ResultContent = JsonConvert.SerializeObject(result);
                    model.CreateDate = _IIntersectsTime.DateNowTimeZone();
                }
            }

            int trackID = await _ServiceMailRepository.Mail_Send(model);
            resp.status = (trackID > 0) ? true : false;
            resp.trackingID = (trackID > 0) ? (result.id == null) ? string.Empty : result.id.ToString() : string.Empty;
            resp.description = (trackID > 0) ? (result.id == null) ? "In Progress..." : string.Empty : string.Empty;

            return resp;

        }

        public async Task<bool> UpdateTrackingAsync(string TrackingID, NipaTrackingStatusResponse ResultContent)
        {
            return await _ServiceMailRepository.UpdateTrackingAsync(TrackingID, ResultContent);
        }


    }
}
