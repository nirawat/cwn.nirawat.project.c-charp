﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CWN.Service.Mail.Entities
{
    [Table("Mail_Tracking")]
    public class Mail_Tracking
    {
        [Key]
        public int Id { get; set; }
        public int SendId { get; set; }
        [Required(ErrorMessage = "JobId is required.")]
        public int JobId { get; set; }
        public DateTime? SendDateTime { get; set; }
        public string TrackingID { get; set; }
        public string TrackingStatus { get; set; }
        public string TrackingResult { get; set; }
        public DateTime? TrackingDate { get; set; }
        public DateTime CreateDate { get; set; }
        public string ErrorType { get; set; }
        public string ErrorRemark { get; set; }
    }

}
