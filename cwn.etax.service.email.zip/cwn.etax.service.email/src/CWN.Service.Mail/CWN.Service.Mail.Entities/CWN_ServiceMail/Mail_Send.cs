﻿using CWN.Service.Mail.Helpers;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace CWN.Service.Mail.Entities
{
    public class Mail_Send
    {
        [Required(ErrorMessage = "ReferenceKey is required.")]
        public string ReferenceKey { get; set; }
        public string ReferenceKey2 { get; set; }
        public string ReferenceKey3 { get; set; }
        [Required(ErrorMessage = "FromName is required.")]
        public string FromName { get; set; }
        [Required(ErrorMessage = "FromEmail is required.")]
        [RegularExpression(@"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", ErrorMessage = "Invalid from_email")]
        public string FromEmail { get; set; }
        [Required(ErrorMessage = "ToEmail is required.")]
        [RegularExpression(@"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", ErrorMessage = "Invalid to_email")]
        public string ToEmail { get; set; }
        [Required(ErrorMessage = "Subject is required.")]
        public string Subject { get; set; }
        [RequireMessageAttribute()]
        public string Message { get; set; }
        [RequireAttachmentAttribute()]
        public string Attachment { get; set; }
        [RequireAttachmentNameAttribute()]
        public string AttachmentName { get; set; }
        [RequireTemplateIDAttribute()]
        public string TemplateID { get; set; }
        [RequireTemplateParameterAttribute()]
        public dynamic TemplateParameter { get; set; }
        public string ResultTrackingID { get; set; }
        public string ResultContent { get; set; }
        public DateTime? ResultTrackingDate { get; set; }
        public DateTime CreateDate { get; set; }
        public bool IsSend { get; set; }
        public DateTime? SendDateTime { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }
        public string PackageKey { get; set; }

    }




    #region "Require Field"

    public class RequireMessageAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (Mail_Send)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (string.IsNullOrWhiteSpace(model.TemplateID) && string.IsNullOrWhiteSpace(model.Message))
            {
                return new ValidationResult("Message is required.", membername);
            }
            return ValidationResult.Success;
        }
    }
    public class RequireAttachmentAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (Mail_Send)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (!string.IsNullOrWhiteSpace(model.AttachmentName) && string.IsNullOrWhiteSpace(model.Attachment))
            {
                return new ValidationResult("Attachment is required.", membername);
            }
            if (!string.IsNullOrWhiteSpace(model.AttachmentName) && !string.IsNullOrWhiteSpace(model.Attachment))
            {
                byte[] fileBytes = Convert.FromBase64String(model.Attachment);
                FileSizeResponse filesize = FileSize.GetFileSize(fileBytes.Length);
                if (filesize.SizeIndex <= 2)
                {
                    if (filesize.SizeName == "MB" && filesize.SizeCount > Convert.ToDecimal(2.0))
                    {
                        return new ValidationResult("The file is large.", membername);
                    }
                }
                else return new ValidationResult("The file is large.", membername);
            }
            return ValidationResult.Success;
        }
    }

    public class RequireAttachmentNameAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (Mail_Send)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (!string.IsNullOrWhiteSpace(model.Attachment) && string.IsNullOrWhiteSpace(model.AttachmentName))
            {
                return new ValidationResult("AttachmentName is required.", membername);
            }
            return ValidationResult.Success;
        }
    }

    public class RequireTemplateIDAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (Mail_Send)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            if (model.TemplateParameter != null && string.IsNullOrWhiteSpace(model.TemplateID))
            {
                return new ValidationResult("TemplateID is required.", membername);
            }
            return ValidationResult.Success;
        }
    }
    public class RequireTemplateParameterAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (Mail_Send)validationContext.ObjectInstance;

            string[] membername = new string[] { validationContext.MemberName };

            string template_parameter = JsonConvert.SerializeObject(model.TemplateParameter);

            if (!string.IsNullOrWhiteSpace(model.TemplateID) && (template_parameter == "{}" || template_parameter == "null"))
            {
                return new ValidationResult("TemplateParameter is required.", membername);
            }
            return ValidationResult.Success;
        }
    }

    #endregion



}
