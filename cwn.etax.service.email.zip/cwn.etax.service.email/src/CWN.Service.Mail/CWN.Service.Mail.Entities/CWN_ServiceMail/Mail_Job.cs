﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CWN.Service.Mail.Entities.CWN_ServiceMail
{
    [Table("Mail_Job")]
    public class Mail_Job
    {
        [Key]
        public int JobId { get; set; }
        public string ReferenceKey1 { get; set; }
        public string ReferenceKey2 { get; set; }
        public string ReferenceKey3 { get; set; }
        public string FromName { get; set; }
        public string FromEmail { get; set; }
        public string ToMail { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public string TemplateID { get; set; }
        public dynamic TemplateParameter { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }
        public DateTime CreateDate { get; set; }
        public string PackageKey { get; set; }
        public string AttachName { get; set; }
        public string AttachFile { get; set; }
    }
}
