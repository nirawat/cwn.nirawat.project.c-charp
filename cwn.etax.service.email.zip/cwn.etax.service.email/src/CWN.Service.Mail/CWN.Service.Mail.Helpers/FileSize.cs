﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CWN.Service.Mail.Helpers
{
    public class FileSize
    {
        public static FileSizeResponse GetFileSize(double byteCount)
        {
            FileSizeResponse _filesize = new FileSizeResponse() { SizeIndex=0, SizeCount = 0, SizeName = "Bytes" };

            if (byteCount >= 1073741824.0)
            {
                _filesize.SizeCount = Convert.ToDecimal(String.Format("{0:##.##}", byteCount / 1073741824.0));
                _filesize.SizeName = "GB";
                _filesize.SizeIndex = 3;
            }
            else if (byteCount >= 1048576.0)
            {
                _filesize.SizeCount = Convert.ToDecimal(String.Format("{0:##.##}", byteCount / 1048576.0));
                _filesize.SizeName = "MB";
                _filesize.SizeIndex = 2;
            }
            else if (byteCount >= 1024.0)
            {
                _filesize.SizeCount = Convert.ToDecimal(String.Format("{0:##.##}", byteCount / 1024.0));
                _filesize.SizeName = "KB";
                _filesize.SizeIndex = 1;
            }
            else if (byteCount > 0 && byteCount < 1024.0)
            {
                _filesize.SizeCount = Convert.ToDecimal(byteCount.ToString());
                _filesize.SizeName = "Bytes";
                _filesize.SizeIndex = 0;
            }

            return _filesize;
        }
    }

    public class FileSizeResponse
    {
        public int SizeIndex { get; set; }
        public string SizeName { get; set; }
        public decimal SizeCount { get; set; }
    }

}
