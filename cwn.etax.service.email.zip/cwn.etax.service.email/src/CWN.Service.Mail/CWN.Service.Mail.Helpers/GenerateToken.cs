﻿using System;

namespace CWN.Service.Mail.Helpers
{
    public class GenerateToken
    {
        public static string GetToken(TimeSpan starttime, TimeSpan endtime)
        {
            Guid guid = Guid.NewGuid();
            string token = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(
                "{" + guid.ToString() + "|" + starttime + "|" + endtime + "}"
                ));
            return token;
        }

    }
}
