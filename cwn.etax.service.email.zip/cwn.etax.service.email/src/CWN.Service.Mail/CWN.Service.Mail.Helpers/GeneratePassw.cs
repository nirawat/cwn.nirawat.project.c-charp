﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CWN.Service.Mail.Helpers
{
    public class GeneratePassw
    {
        public static string GetPassword(string passw)
        {
            Guid guid = Guid.NewGuid();
            string token = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("{"+ passw + "}"));
            return token;
        }

    }
}
