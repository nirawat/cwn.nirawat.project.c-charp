﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CWN.Service.Mail.Helpers
{
    public interface IAESHelper
    {
        string Encrypt(string text);
        string Decrypt(string cipherText);
    }
    public class AESHelper: IAESHelper
    {
        private readonly IConfiguration configuration;
        private readonly string keys;
        private readonly IDataProtectionProvider _dataProtectionProvider;
        public AESHelper(IConfiguration configuration,
            IDataProtectionProvider dataProtectionProvider)
        {
            this.configuration = configuration;
            _dataProtectionProvider = dataProtectionProvider;
            this.keys = this.configuration["AesKey"];
        }

        public string Encrypt(string text)
        {
            var protector = _dataProtectionProvider.CreateProtector(keys);
            return protector.Protect(text);            
        }

        public string Decrypt(string cipherText)
        {
            var protector = _dataProtectionProvider.CreateProtector(keys);
            return protector.Unprotect(cipherText);            
        }
    }
}
