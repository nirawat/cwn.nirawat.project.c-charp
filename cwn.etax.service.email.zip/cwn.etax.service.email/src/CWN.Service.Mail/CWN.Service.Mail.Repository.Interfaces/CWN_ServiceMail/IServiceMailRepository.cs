﻿using CWN.Service.Mail.Entities;
using CWN.Service.Mail.Entities.CWN_ServiceMail;
using CWN.Service.Mail.Models.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CWN.Service.Mail.Repository.Interfaces
{
    public interface IServiceMailRepository
    {
        Task<int> Mail_Send(Mail_Send model);
        Task<IList<Mail_Job>> GetAll_Jobs();
        Task<bool> UpdateTrackingAsync(string TrackingID, NipaTrackingStatusResponse ResultContent);
    }
}
