﻿namespace CWN.Service.Mail.RobotTask.Configs
{
    public interface IRobotConfig
    {
        int SendProcess { get; set; }
        int SendDelay { get; set; }
    }

    public class RobotConfig : IRobotConfig
    {
        public int SendProcess { get; set; }
        public int SendDelay { get; set; }
    }
}
