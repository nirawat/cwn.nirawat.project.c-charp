using CWN.Service.Email.Helpers;
using CWN.Service.Mail.Entities.CWN_ServiceMail;
using CWN.Service.Mail.Models.Resources;
using CWN.Service.Mail.Models.Response;
using CWN.Service.Mail.RobotTask.ApiConnector;
using CWN.Service.Mail.RobotTask.Configs;
using CWN.Service.Mail.RobotTask.Model;
using CWN.Service.Mail.RobotTask.SendJobServices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CWN.Service.Mail.SendJobServices
{
    internal class RobotServiceSendJob : IHostedService, IDisposable
    {
        private readonly IConfiguration _configuration;
        private static string ConnectionString;
        private static string MaxData;
        private IRobotConfig _robotconfig;
        private INipaMailConfig _nipamailconfig;
        private string _url_sendmail;
        private string _attach_type;
        private readonly ILogger _logger;
        private Timer _timer;

        public RobotServiceSendJob(
                                IConfiguration configuration,
                                IBackgroundTaskQueueSendJob queue,
                                ILogger<RobotServiceSendJob> logger,
                                IRobotConfig robotconfig,
                                INipaMailConfig nipamailconfig)
        {
            _configuration = configuration;
            _logger = logger;
            Queue = queue;
            _robotconfig = robotconfig;
            _nipamailconfig = nipamailconfig;
            ConnectionString = Encoding.UTF8.GetString(Convert.FromBase64String(_configuration.GetConnectionString("dbServiceMail")));
            MaxData = _configuration.GetConnectionString("MaxData");

            _url_sendmail = Encoding.UTF8.GetString(Convert.FromBase64String(_nipamailconfig.SendMailUrl));
            _url_sendmail = $"{string.Format(_url_sendmail, _nipamailconfig.TokenKey)}";
            _attach_type = Encoding.UTF8.GetString(Convert.FromBase64String(_nipamailconfig.AttachType));
        }

        public IBackgroundTaskQueueSendJob Queue { get; }
        private IList<Mail_Job> list_temp_jobs = new List<Mail_Job>();

        public static DateTime DateNowTimeZone()
        {
            // return DateTime.Now;

            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Asia/Bangkok");
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZoneInfo);

        }

        public Task StartAsync(CancellationToken cancellationToken)
        {

            _logger.LogInformation("Robot Service is starting.");

            _timer = new Timer(DoWork, null, TimeSpan.Zero, TimeSpan.FromSeconds(_robotconfig.SendProcess));

            return Task.CompletedTask;
        }

        private void DoWork(object state)
        {
            if (list_temp_jobs.Count >= Convert.ToInt32(MaxData)) list_temp_jobs.Clear();

            Queue.QueueBackgroundWorkItem(async token =>
            {
                IList<Mail_Job> list_jobs = await GetAllByJobAsync();

                if (list_jobs.Count > 0)
                {
                    foreach (Mail_Job jobs in list_jobs)
                    {
                        int duplicate_job = list_temp_jobs.Where(e => e.JobId == jobs.JobId).Count();

                        if (duplicate_job <= 0)
                        {
                            list_temp_jobs.Add(new Mail_Job() { JobId = jobs.JobId });
                            DateTime dtnow = DateNowTimeZone();
                            try
                            {

                                NipaMailResource mail = new NipaMailResource();

                                mail.package_key = jobs.PackageKey;
                                if (!string.IsNullOrWhiteSpace(jobs.AttachFile))
                                {
                                    mail.attach_type = _attach_type;
                                    mail.attachment = JsonConvert.DeserializeObject("{ 'name': '" + jobs.AttachName + "', 'string': '" + jobs.AttachFile + "' }");
                                }

                                mail.from_name = jobs.FromName;
                                mail.from_email = jobs.FromEmail;
                                mail.to = jobs.ToMail;
                                mail.subject = jobs.Subject;
                                mail.message = jobs.Message;
                                if (!string.IsNullOrEmpty(jobs.TemplateID))
                                {
                                    mail.template_id = jobs.TemplateID;
                                    mail.parameters = JsonConvert.DeserializeObject(jobs.TemplateParameter);
                                }

                                string requestUri = $"{_url_sendmail}";
                                using (var httpResponse = await HttpRequestFactory.Post(requestUri, string.Empty, mail))
                                {
                                    NipaSendMailResponse result = JsonConvert.DeserializeObject<NipaSendMailResponse>(httpResponse.ContentAsString());
                                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                                        await SavByJobAsync(jobs.JobId, dtnow, result);
                                    else await SavByJobErrorAsync(jobs.JobId, dtnow, httpResponse.StatusCode.ToString(), result);
                                }

                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, "database. Error: {ex.Message}");
                            }
                            await Task.Delay(TimeSpan.FromSeconds(_robotconfig.SendDelay), token);
                        }
                    }
                }
            });
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            list_temp_jobs.Clear();

            _logger.LogTrace("Robot Service is stopping.");

            _timer?.Change(Timeout.Infinite, 0);

            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }


        #region SqlExcute

        private static async Task<IList<Mail_Job>> GetAllByJobAsync()
        {
            TimeSpan _timenow = DateNowTimeZone().TimeOfDay;

            IList<Mail_Job> list_jobs = new List<Mail_Job>();

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                await conn.OpenAsync();

                using (SqlCommand cmd = new SqlCommand("sp_GetPeriodByJob", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@TimeNow", SqlDbType.Time, 7).Value = _timenow;
                    cmd.Parameters.Add("@MaxRowData", SqlDbType.Int).Value = Convert.ToInt32(MaxData);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Mail_Job jobs = new Mail_Job();
                        jobs.JobId = (int)reader["JobId"];
                        jobs.ReferenceKey1 = reader["ReferenceKey1"].ToString();
                        jobs.ReferenceKey2 = reader["ReferenceKey2"].ToString();
                        jobs.ReferenceKey3 = reader["ReferenceKey3"].ToString();
                        jobs.FromName = reader["FromName"].ToString();
                        jobs.FromEmail = reader["FromEmail"].ToString();
                        jobs.ToMail = reader["ToMail"].ToString();
                        jobs.Subject = reader["Subject"].ToString();
                        jobs.Message = reader["Message"].ToString();
                        jobs.TemplateID = reader["TemplateID"].ToString();
                        jobs.TemplateParameter = reader["TemplateParameter"].ToString();
                        jobs.PackageKey = reader["PackageKey"].ToString();
                        jobs.AttachName = reader["AttachName"].ToString();
                        jobs.AttachFile = reader["AttachFile"].ToString();

                        list_jobs.Add(jobs);
                    }
                    reader.Close();
                }
                conn.Close();
                conn.Dispose();
            }
            return list_jobs;
        }

        private async Task SavByJobAsync(int JobId, DateTime dtnow, NipaSendMailResponse result)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                await conn.OpenAsync();

                using (SqlCommand cmd = new SqlCommand("sp_Mail_Job", conn))
                {
                    string ResultTrackId = string.Empty;
                    string ResultContent = (result.message == null) ? string.Empty : result.message;
                    if (result.status_code == "200")//Success
                    {
                        ResultTrackId = result.id;
                        ResultContent = JsonConvert.SerializeObject(result);
                    }

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@JobId", SqlDbType.Int).Value = JobId;
                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = dtnow;
                    cmd.Parameters.Add("@SendDateTime", SqlDbType.DateTime).Value = dtnow;
                    cmd.Parameters.Add("@ResultTrackingID", SqlDbType.VarChar, 200).Value = ParseDataHelper.ConvertDBNull(ResultTrackId);
                    cmd.Parameters.Add("@ResultContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(ResultContent);

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;
                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();
                }
                conn.Close();
                conn.Dispose();
            }
        }

        private async Task SavByJobErrorAsync(int JobId, DateTime dtnow, string StatusCode, NipaSendMailResponse result)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                await conn.OpenAsync();
                using (SqlCommand cmd = new SqlCommand("sp_Mail_Job_ErrorLog", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@JobId", SqlDbType.Int).Value = JobId;
                    cmd.Parameters.Add("@DateTimeNow", SqlDbType.DateTime).Value = dtnow;
                    cmd.Parameters.Add("@LogEvent", SqlDbType.VarChar, 200).Value = ParseDataHelper.ConvertDBNull(StatusCode);
                    cmd.Parameters.Add("@LogContent", SqlDbType.NVarChar).Value = ParseDataHelper.ConvertDBNull(JsonConvert.SerializeObject(result));

                    SqlParameter rStatus = cmd.Parameters.Add("@rStatus", SqlDbType.Int);
                    rStatus.Direction = ParameterDirection.Output;
                    SqlParameter rMessage = cmd.Parameters.Add("@rMessage", SqlDbType.NVarChar, 500);
                    rMessage.Direction = ParameterDirection.Output;

                    await cmd.ExecuteNonQueryAsync();
                }
                conn.Close();
                conn.Dispose();
            }
        }
        #endregion


    }
}
